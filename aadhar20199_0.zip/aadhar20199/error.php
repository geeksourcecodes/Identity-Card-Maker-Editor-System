<center>
<h1> Aadhar Card not Generated #Error 404  <h1>
<h3> Aadhar card not generated. Please contact nearest enrollment center to apply aadhar card <h3>
<li><a  href="https://localhost/aadhar/logout.php">Home Page</a></li>