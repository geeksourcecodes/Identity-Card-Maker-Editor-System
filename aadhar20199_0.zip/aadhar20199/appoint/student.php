<?php require_once ("includes/header.php");?>

	<div id="content">
        <div class="content_item">
        <h2>Citizen Dashboard</h2>
            <br style="clear:both;" />
            <?php
            
	  		?>
            
        </div><!--close content_item-->
    </div><!--close content-->  
</div><!--close site_content-->
<?php include 'includes/footer.php';?>