	<div id="content_grey" class="row">
	<div class="col-md-12">
	  <div class="col-md-4">
		<h4>Latest Blog Post</h4>
	    <p> Admission Announcement for Post Graduate Diploma for Academic session 2017-18</p>
		<div>
		  <a href="#" class="btn btn-xs btn-default" >Read more</a>
		</div><!--close readmore-->
	  </div><!--close content_grey_container_box-->
      <div class="col-md-4">
       <h4>Latest News</h4>
	    <p> Pre-bid meeting clarification for House Keeping Services (Last Date:03/07/2017)</p>
	    <div>
		  <a href="#" class="btn btn-xs btn-default">Read more</a>
		</div><!--close readmore-->
	  </div><!--close content_grey_container_box-->
      <div class="col-md-4">
		<h4>Latest Projects</h4>
	    <p> Aregbesola invites Tender Quotations for engagement of Security Agency</p>
	    <div>
		  <a href="#" class="btn btn-xs btn-default">Read more</a>
		</div><!--close readmore-->	  
	  </div><!--close content_grey_container_box1-->      
	  <br style="clear:both"/>
    </div><!--close content_grey-->   
   </div>
  </div><!--close main-->
  
  <div id="footer">
	  <a href="http://validator.w3.org/check?uri=referer">Valid XHTML</a> | <a href="http://fotogrph.com/">Images</a> | Designed & Developed by <a href="https://www.facebook.com/lewabloke">Create Networks NG</a>.
  </div><!--close footer-->  
</body>
</html>
<?php
	if (isset($connection)) {
		mysql_close($connection);
	}
?>