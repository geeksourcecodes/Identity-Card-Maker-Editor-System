<div class="form-group">
  <label class="control-label col-md-2">DOB Documnet Type</label>
  <div class="col-md-4">
    <select name="exam" id="exam" class="form-control" required>
    	<option value="Maticulation Certificate">Maticulation Certificate</option>
    	<option value="Photo ID Issued by Gram Panchayat">Photo ID Issued by Gram Panchayat</option>
    	<option value="Voter ID">Voter ID</option>
    	<option value="Birth Certificate By Munispality">Birth Certificate By Munispality</option>
    </select>
    <span id="exam-error" class="signup-error help-block"></span>
</div>
</div>

<div class="form-group">
  <label class="control-label col-md-2">DOB Proof</label>
  <div class="col-md-6">
  <input type="file" name="result" id="result" class="demoInputBox form-control" required />
    <span id="result-error" class="signup-error help-block"></span>
</div>
</div>

<div class="form-group">
  <label class="control-label col-md-2">Aadhar Number</label>
  <div class="col-md-10">
  <input type="text" name="jambreg" id="jambreg" class="demoInputBox form-control" required />
    <span id="jambreg-error" class="signup-error help-block"></span>
</div>
</div>

<div class="form-group">
  <label class="control-label col-md-2">Address Proof</label>
  <div class="col-md-6">
  <input type="file" name="jamb" id="jamb" class="demoInputBox form-control" required />
    <span id="jamb-error" class="signup-error help-block"></span>
</div>
</div>