<p class="text-justify">
	I, declare that all information provide above are genuine and correct. Citizen should be aware that falsification of any information is automatic Rejection. Kindly review inputted information before clicking the '<b>Finish</b>' button.

	<b style="color: red">Note: Change of Bio-data cannot be done after submission</b>.
</p>
<div class="form-group">
	<input class="checkbox" id="attest" type="checkbox" name="declaration" value="accept" required />&nbsp;Declaration by Applicant
	 <span id="attest-error" class="signup-error help-block"></span>
</div>
