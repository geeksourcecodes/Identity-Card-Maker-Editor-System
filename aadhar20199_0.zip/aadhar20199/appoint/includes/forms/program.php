<div class="form-group">
  <label class="control-label col-md-2">Screeing Day</label>
  <div class="col-md-4">
    <select name="program" id="program" class="form-control" required>
    	<option value="NEXTDAY">NEXT DAY</option>
    	<option value="NEXTNEXTDAY">A DAY AFTER TOMMORROW</option>
    </select>
    <span id="program-error" class="signup-error help-block"></span>
</div>
</div>