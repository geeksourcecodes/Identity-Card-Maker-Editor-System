<?php

include("db.php");


$id = $_POST['jambreg'];
$ref_number = $_POST['ref_number'];
$name = $_POST['u_name'];
$dob = $_POST['dob'];
$gender = $_POST['gender'];
$phone = $_POST['phone'];
$admission_status = $_POST['admission_status'];


$count = count($id);

for($c = 0; $c < $count; $c++){
$result = mysql_query("UPDATE students SET ref_number='$ref_number[$c]', name='$name[$c]', dob='$dob[$c]', gender='$gender[$c]', phone='$phone[$c]', admission_status='$admission_status[$c]' WHERE jambreg='$id[$c]'") or die(mysql_error());

}
header("location: index.php");

?>