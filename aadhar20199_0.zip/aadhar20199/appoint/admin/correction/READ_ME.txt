Add / Multi Delete & Edit Data in one Page
Coded in Php. This is a simple example on how to 
make multiple modifications of database content 
without navigating from one page to another. 
If you follow it carefully, you will get to know how
 I achieved this. In this application, you can add content, 
check all, uncheck all, delete and edit all checked boxes in one single page. 

To get exactly the layout shown on the screenshot, 
use Google Chrome to preview this application as I used Html5 and Css3.

Database name: del

Need assistance on this or need my help?
Call +2348066459789
Email: vifeanyi33@gmail.com
