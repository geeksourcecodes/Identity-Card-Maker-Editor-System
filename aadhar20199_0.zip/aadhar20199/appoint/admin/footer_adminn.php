	<div id="content_grey">
	  <div class="content_grey_container_box">
		<h4>Latest Blog Post</h4>
	    <p> Admission Announcement for Post Graduate Diploma for Academic session 2017-18</p>
		<div class="readmore">
		  <a href="#">Read more</a>
		</div><!--close readmore-->
	  </div><!--close content_grey_container_box-->
      <div class="content_grey_container_box">
       <h4>Latest News</h4>
	    <p> Pre-bid meeting clarification for House Keeping Services (Last Date:03/07/2017)</p>
	    <div class="readmore">
		  <a href="#">Read more</a>
		</div><!--close readmore-->
	  </div><!--close content_grey_container_box-->
      <div class="content_grey_container_boxl">
		<h4>Latest Projects</h4>
	    <p> Aregbesola invites Tender Quotations for engagement of Security Agency</p>
	    <div class="readmore">
		  <a href="#">Read more</a>
		</div><!--close readmore-->	  
	  </div><!--close content_grey_container_box1-->      
	  <br style="clear:both"/>
    </div><!--close content_grey-->   
 
  </div><!--close main-->
  
  <div id="footer">
	  <a href="http://validator.w3.org/check?uri=referer"></a> | <a href="http://fotogrph.com/">Images</a> | Designed & Developed by <a href="https://www.facebook.com/lewabloke">Create Networks NG</a>.
  </div>
  <script>
 
</body>
</html>
<?php
	if (isset($connection)) {
		mysql_close($connection);
	}
?>