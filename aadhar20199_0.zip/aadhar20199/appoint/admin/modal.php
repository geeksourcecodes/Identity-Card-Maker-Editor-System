<div id="myModal" class="modal modal-md fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h3 class="modal-title">Offer Admission?</h3>
      </div>
      <div class="modal-body">
       <div class="alert alert-danger">
          <p>Are you sure you want to offer the following admission?.</p>
          </div>
      </div>
      <div class="modal-footer">
       <button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove icon-large"></i> Close</button>
          <button name="accept" class="btn btn-danger"><i class="icon-check icon-large"></i> Yes</button>
      </div>
    </div>

  </div>
</div>