<?php include 'includes/header.php';?>
      <div id="content">
        <div class="content_item" class="container">
          <div class="col-md-12">
            <div class="well well-md">
              <?php 
                $sid = $_GET['sid'];
                $result = mysql_query("SELECT admission_status FROM students WHERE id = '$sid' AND admission_status = 1 ",$connection);
                confirm_query($result);
                 if (mysql_num_rows($result) == 1) { ?>
                      <h3>Verification Letter of Aadhar to <?php echo $result_set['name']?></h3>
                      <p>Dear <?php echo $result_set['name']."," ?></p>
                      <p>
                        Congratulations! We are verified your Address and Supporting Document attched with Aadhar No. <h3><?php echo $result_set['jambreg']."" ?></h3>
<li><?php echo $result_set['name']."" ?> (<?php echo $result_set['gender']."" ?>)</li>
<li><?php echo $result_set['h_address']."" ?></li>
<li><?php echo $result_set['phone']."" ?></li>
                      </p>
                      <p>
                        PROCEDURE FOR APPLY NEW AADHAR CARD AT YOUR NEAREST AADHAR ENROLLMENT CENTER

YOU ARE EXPECTED TO PAY THE NEW CARD FEE RS. 50 ONLY ON ENROLLEMENT CENTER. PLEASE NOTE THAT THE ACCEPTANCE FEE IS NON-REFUNDABLE . NOTE THAT UNDER NO CIRCUMSTANCE WOULD THE DATE FOR THE PAYMENT OF ACCEPTANCE FEE BE EXTENDED.
<ol>
<li>PAY YOUR ACCEPTANCE FEE AT AADHAR ENROLLMENT CENTER.</li>
<li>READY FOR BIOMETRICS NEEDED FOR APPLYING AADHAR CARD IE. RETINA SCAN, THUMB IMPRESSION, FACE RECOGNSATION.</li>
<li>KEEP YOUR RECEIPT AND CLEARANCE SCHEDULE FOR FUTURE REFFERENCE.</li>
<li>DEADLINE FOR APPLYING AADHAR WITHIN 1 MONTH AFTER VERIFICATION.</li>
</ol>
<h3>THE FOLLOWING DOCUMENTS ARE REQUIRED FOR APPLYING AADHAR CARD:</h3>
<ol>
<li>APPOINTMENT SCHEDULE APPLICATION AND VERIFICATION LETTER.</li>
<li>SUPPORTING DOCUMENT FOR DOB AS UPLOADED BEFORE  <h4><?php echo $result_set['exam']."" ?></h4></li>
<li>ADDRESS PROOF.</li>
<li>RECEIPT FOR PAYMENT MADE FROM CHALLAN. (IF APPLICABLE)</li>

</ol>


<br>
<br>
<br>
<br>

SIGNED<br>
---------------------<br>
REGISTRAR
                      </p>

                  <?php }else{ ?>
                    <h4 style="color:red">Sorry, no Officer visited at your Place yet. Check back later.</h4>
                   <?php } ?>
             
            </div>  
      </div>
      </div><!--close content-->  
    </div><!--close site_content-->  
 <?php //include 'includes/footer.php';?>



