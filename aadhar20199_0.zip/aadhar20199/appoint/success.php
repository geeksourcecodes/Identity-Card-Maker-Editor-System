<?php include 'includes/header.php';?>
      <div id="content">
        <div class="content_item" class="container">
        	<div class="col-md-12">
        		<div class="well well-md">
               <h3>
               	<p>Registration Successfully. Click the link below to login to your school portal</p>
               </h3>
               	<center><a href="signin.php" class="btn btn-md btn-success btn-group">Proceed to Login</a></center>
            
               </div>	 
			</div>
      </div><!--close content-->  
    </div><!--close site_content-->  
 <?php //include 'includes/footer.php';?>

