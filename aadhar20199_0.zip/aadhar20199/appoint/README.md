Admission System

Install
1. Import the database admdb.sql
2. upload all folder contents to www directory of your server
3. point address to foldername/index.php in browser

For any query you can mail at omolewastephen@gmail.com or https://facebook.com/createnetworksng or 08140034274/08073047104

Thanks
