<?php require_once ("includes/session.php");?>
<?php require_once ("includes/connection.php");?>
<?php require_once ("includes/functions.php");?>
<?php
  $sid = $_GET['sid'];
  $std = getstd($sid);

  $surname = strtoupper($std['surname']);
  $name = $std['name'];
  $jambreg = $std['jambreg'];
  $email = $std['email'];
  $phone = $std['phone'];
  $gender = $std['gender'];
  $address = $std['h_address'];
  $passport = $std['passport'];
  $local = $std['local'];
  $state_id = $std['state_id'];
  $program = $std['program'];
$exam = $std['exam'];


  $lc = getlocal($local);

  $lcname = $lc['local_name'];

  $sn = getstate($state_id);

  $sname = $sn['name'];



?>
<head>
  <title>Appointment For Aaadhar Verification</title>
  <meta name="description" content="website" />
  <meta name="keywords" content="enter your keywords here" />
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=9" />
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
  <script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<style type="text/css">
	h1{
		font-family: arial;
		font-size: 40px;
		float: right;
		margin-right: 10%;
		width: 60%;
		color: #3d46cd
	}
	h1 >small{
        font-size: 14px;
        font-weight: bold;
        color: black;
	}
	.wrap{
		width: 100%;
		height: 150px;
		color: black
	}
	.wrap> .img{
		float: left;
        width: 30%;
	}
	h4{
      text-decoration: underline;
	}
	table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
th, td {
    padding: 5px;
    text-align: left;    
}
	
</style>
</head>

<body>
  <center>
	<div class="container" style="height: 100%;">
		<div class="wrap">
			<div class="img">
			<img src="images/aadhar.png" width="100" height="100" style="margin-top: 2%">
		   </div>
	        <h1>Appointment For Aaadhar Verification<br>
	        	<small>Gov. of India</small>
	         </h1>  
        </div>
        <div style="clear: both"></div>
        <h4> Schedule for <?php echo $jambreg; ?> </h4>
        <div class="row">
        	<div class="col-md-8">
        		<h4>Schedule</h4>
        		<table style="width:80%">
				  <tr>
				    <th>Name:</th>
				    <td><?php echo $name.""." ".$surname; ?></td>
				  </tr>
				  <tr>
				    <th rowspan="1">Aadhar Number:</th>
				    <td><?php echo $jambreg; ?></td>
				  </tr>
				   <tr>
				    <th rowspan="1">Screening Date:</th>
				    <td><?php echo $program; ?></td>
				  </tr>
				   <tr>
				    <th rowspan="1">Screening Venue:</th>
				    <td><?php echo $address; ?></td>
				  </tr>

				  <tr>
				    <th rowspan="1">Screening State:</th>
				    <td><?php echo $sname; ?></td>
				  </tr>

				  <tr>
				    <th rowspan="1">Phone:</th>
				    <td><?php echo $phone; ?></td>
				  </tr>

				   <tr>
				    <th rowspan="2">Status :</th>
				    <td>Verified (1)</td>
				  </tr>
				  <tr>
				  	 <td>Not Verified (0)</td>
				  </tr>

				  <tr>
				    <th rowspan="3">Required Documents:</th>
				    <td><?php echo $exam; ?> For DOB</td>
				  </tr>
				  <tr>
				  	 <td>Schedule Form</td>
				  </tr>
				   <tr>
				  	 <td>Address proof and photo(same as uploaded)</td>
				  </tr>
				
				</table>
        	</div>
        	<div class="col-md-3 col-md-offset-1">
        		<h4><?php echo $jambreg; ?></h4>
        		<img src="<?php echo $passport; ?>" width="120px" height="100px" class="img img-responsive thumbnail">
			
        	</div>

        </div>
    </div>
   </center>
</body>