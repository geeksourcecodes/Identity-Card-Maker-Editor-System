<center>
<h1> Your Aadhar Number is already linked with your Pan Number <h1>
<li><a  href="https://localhost/aadhar/logout.php">Home Page</a></li>
