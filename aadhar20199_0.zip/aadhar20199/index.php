<html>


<head>
<link rel="stylesheet" type="text/css" href="styles.css"></link>


</head>

 <body>

<div class="page">
 <div class="headerpart"></div>
  <div class="linkspart">
   <center>
   <a href="index.php">Home</a> &nbsp&nbsp
<a href="signup.php">Generate Aadhar</a>&nbsp&nbsp
<a href="login.php">Book Appointment</a>&nbsp&nbsp
<a href="downloadaadhar.php">Print Aadhar</a>&nbsp&nbsp
<a href="linkaadhar2.php">Link Pan</a>&nbsp&nbsp
<a href="adminlogin.php">Apply Aadhar (Enrollemnt Center)</a>&nbsp&nbsp
<a href="appoint/admin/admin_login.php">Survey Offcier Login (Address verification)</a>&nbsp&nbsp
<a href="AAI">Apply E-Passport (Airpot Authority of India)</a>&nbsp
<a href="AAI/visaverify/">Check Visa Status</a>

   </center>



 </div>

<div class="bodypart">
<div class="imagepart"></div>
<div class="newspart">
<h2> News & Announcements </h2>
  <div class="news">

    <marquee direction="up" height="100%">
   <h4>How to Apply for New Aadahr Card  </h4> <br>
    <p> Step 1: Citizen has to Generate Aadhar Number.<br>
Step 2: Citizen has to login through Aadhar Number and P-OTP  to schedule a appointment for verification.<br>
Step 3: Survey Officer came to that address and check all details and verify the citizen by whom aadhar is applied<br>
Step 4: After Verification A verification letter is generated online for citizen (obtained by login through Aadhar number and P-OTP). This Letter is mandatory for applyig Aadhar card .<br>
Step 5: Go to the nearest Aadhar Enrollment Center to apply aadhar card with relevent documents :<br>
                          a) Address Proof<br>
                          b)DOB Proof<br>
                          c) Aadhar Verification Letter<br>
                          d)Verifcation Schedule Application<br>
Step 6: Pay Rs.50 for applying Aadhar card through Cash or Challan<br>
Step 7 : Ready for Biometrics like retina , thumb,face<br>
Step 8: Download Aadhar Card<br>
    <hr>
    <h4> Book an Appointment </h4><br>
    <p> Login in Book Appointment Section through Aadhar Number and P-OTP. And schedule appointment to verify your address, Documents. After Verification within 24 hours a verification letter has been issued to your profile online.This letter help you to apply aadhar card
    <hr>
   </marquee>
   <a href="morenews.html">more news...</a>

</div>
  
</div>
<h3> About Aadhar Portal </h3>
<p> Aadhaar (English: foundation or base) is a 12-digit unique identity number that can be obtained voluntarily by residents of India, based on their biometric and demographic data.<br> The data is collected by the Unique Identification Authority of India (UIDAI), a statutory authority established in January 2009 by the government of India, under the jurisdiction of the Ministry of Electronics and Information Technology, following the provisions of the Aadhaar (Targeted Delivery of Financial and other Subsidies, benefits and services) Act, 2016.[1]</p>
</div>

<div class="footerpart">
<center> 2019 All Right Reserved. Online Aadhar Portal</center>
</div>
</div>



</body>



</html>