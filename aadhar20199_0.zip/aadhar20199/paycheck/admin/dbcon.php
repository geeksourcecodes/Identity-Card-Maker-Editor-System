<?php
mysql_select_db('oas2',mysql_connect('localhost','root',''))or die(mysql_error());
?>