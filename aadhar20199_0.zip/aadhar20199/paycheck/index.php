<?php 

    
include('header.php');
?>
<body>
<div class="container">

<br>
<br>
<br>
<br>

   
<div class="thumbnail" style="border:1px solid #1982d1; background:;">
     <div class="row">
	<div class="span3 offset1"></div>
    <div class="span8">
	<br>
	
	<div class="alert alert-danger"><b><i class="icon-file"></i> Link Your Aadhar number to Pan number</b></div>
	
	<form class="form-horizontal" method="POST">
	 
    <div class="control-group">
    <label class="control-label" for="inputEmail">Aadhar number</label>
    <div class="controls">
    <input type="text" class="span4" name="s_id" id="inputEmail" placeholder="AADHAR00001" autofocus="autofocus" required>
    </div>
    </div>

<div class="control-group">
    <label class="control-label" for="inputEmail">Name</label>
    <div class="controls">
    <input type="text" class="span4" name="s_nname" id="inputEmail" placeholder="Avinash Kumar" autofocus="autofocus" required>
    </div>
    </div>
	
	<div class="control-group">
    <label class="control-label" for="inputEmail">Pan Number</label>
    <div class="controls">
    <input type="text" class="span4" name="s_name" id="inputEmail" placeholder="DOHKL7425O" required>
    </div>
    </div>

	<div class="control-group">
    <label class="control-label" for="inputEmail">Pan Card link ID</label>
    <div class="controls">
    <input type="text" class="span4" name="s_mob" id="inputEmail" placeholder="DE00000001" required>
    </div>
    </div>
	
	
	 
	<div class="control-group">
    <label class="control-label" for="inputEmail">State</label>
    <div class="controls">
	<select class="span2" name="bank" required>
	<option>BIHAR</option>
	<option>UTTAR PRADESH</option>
	<option>ODISHA</option>
	<option>MAHARASTRA</option>
	<option>MADHYA PRADESH</option>
	<option>JHARKHAND</option>
<option>ASSAM</option>
<option>GUJRAT</option>
<option>KERALA</option>
<option>CHENNAI</option>
<option>ANDRA PRADESH</option>
<option>TELANGANA</option>
<option>KARNATAKA</option>
<option>JAMMU AND KASHMIR</option>
<option>PANJAB</option>
<option>HIMACHAL PRADESH</option>
<option>UTTARAKHAND</option>
<option>NEW DELHI</option>
<option>MEGHALAYA</option>
<option>RAJASTHAN</option>
<option>GOA</option>
<option>TRIPURA</option>
<option>MIZORAM</option>
<option>ARUNACHAL PRADESH</option>
<option>SIKKIM</option>
<option>NAGALAND</option>
<option>WEST BANGAL</option>
<option>CHANDIGADH</option>
<option>PUDDUCHERRY</option>
	</select>
    </div>
    </div>
	
	
	
	
	
	<div class="control-group">
		<div class="controls">
		
		<img src="generatecaptcha.php?rand=<?php echo rand(); ?>" name="captcha_img" id='image_captcha' > 
		<a href='javascript: refreshing_Captcha();'><i class="icon-refresh icon-large"></i></a> 
		<script language='JavaScript' type='text/javascript'>
			function refreshing_Captcha()
			{
				var img = document.images['image_captcha'];
				img.src = img.src.substring(0,img.src.lastIndexOf("?"))+"?rand="+Math.random()*1000;
			}
		</script>
		</div>
	</div>
	
	<div class="control-group">
    <label class="control-label" for="inputEmail">Captcha Confirmation</label>
    <div class="controls">
    <input type="text" class="span4" name="captcha_code" id="inputEmail" placeholder="Enter the Captcha Code above" required>
    </div>
    </div>
 
    <div class="control-group">
    <div class="controls">
    <button type="submit" name="submit" class="btn btn-primary"><i class="icon-save icon-large"></i> Link</button>
    </div>
    </div>
    </form>
	
	</div>
    </div>
	</div>
	<center>
	<div class="alert alert-danger" role="alert">
	<b>Aadhar linkage powered by Tax Ministry</b>
	</div>
	</center>
	
	<?php
	if (isset($_POST['submit'])){
	$s_id = $_POST['s_id'];
	$s_nname = $_POST['s_nname'];
	$s_name = $_POST['s_name'];
	$s_mob = $_POST['s_mob'];
	$bank = $_POST['bank'];
	$captcha_code = $_POST['captcha_code'];
	
	mysql_query("insert into paycheck (s_id, s_nname, s_name, s_mob, bank, captcha_code, date)
	values('$s_id', '$s_nname', '$s_name', '$s_mob', '$bank', '$captcha_code',NOW())
	")or die(mysql_error());
	?>
	<script type="text/javascript">
	alert('Your Aadhar number Linked to your Pan number');
	window.location="http://localhost/aadhar/logout.php";
	</script>

	<?php
	}
	?>
	
	
</div>
</body>
</html>