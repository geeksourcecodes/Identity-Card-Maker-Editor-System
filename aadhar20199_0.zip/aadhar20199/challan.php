<?php

    session_start();
    error_reporting(0);

$con=mysqli_connect("localhost","root","","oas2");
$q=mysqli_query($con,"select s_name from t_user_data where s_id='".$_SESSION['user']."'");
$n=  mysqli_fetch_assoc($q);
$stname= $n['s_name'];
$id=$_SESSION['user'];

$result = mysqli_query($con,"SELECT * FROM t_user_data WHERE s_id='".$_SESSION['user']."'");
                    
                    while($row = mysqli_fetch_array($result))
                      {
?>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
        
         <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
         <link rel="stylesheet" href="bootstrap/bootstrap-theme.min.css">
       <script src="bootstrap/jquery.min.js"></script>
        <script src="bootstrap/bootstrap.min.js"></script>
        <link type="text/css" rel="stylesheet" href="css/admform.css"></link>
        
        <script type="text/javascript">
            function printpage()
            {
            var printButton = document.getElementById("print");
            printButton.style.visibility = 'hidden';
            window.print()
             printButton.style.visibility = 'visible';
             }
        </script>
        
        
    </head>
    <body>
        <div class="container-fluid">
                            <div class="row">
                               <div class="col-sm-12">
      <center>  <table class="table table-bordered" style="font-family: Verdana">
               
                <tr>
                 <td style="width:3%;"><br><br><img src="./images/right-logo.png" width="100%"> </td>
                 <td style="width:8%;"><center><font style="font-family:Arial Black; font-size:20px;">
                     <br><br>
                    Challan</font></center>
                
                <center><font style="font-family:Verdana; font-size:18px;">
                    (OFFICE PAYMENT CHANNEL) Candidate Copy
                    </font></center>
                
                <br>
                <br>
                <center><font style="font-family:Arial Black; font-size:20px;">
                    APPLICATION CODE : 01/2019</font></center>
                </td>
 
                    <td colspan="2" width="3%" >
                    <?php
                  
                    $picfile_path ='studentpic/right-logo.png';
                    
                    $result1 = mysqli_query($con,"SELECT * FROM t_userdoc where s_id='".$_SESSION['user']."'");
                        
                    
                    
                    while($row1 = mysqli_fetch_array($result1))
                      {                  
                        $picsrc=$picfile_path;
                        
                        echo "<img src='./images/right-logo.png.' class='img-thumbnail' width='180px' style='height:180px;'>";
                        echo"<div>";
                      
                      }
                      
                    
                      
                      
                        $resdata = mysqli_query($con,"SELECT * FROM t_user_data WHERE s_id='".$_SESSION['user']."'");
                    
                    while($rowdata = mysqli_fetch_array($resdata))
                      {
                        
                    
                   ?>
                        </td>
                 </tr>       
                 
                 <tr>
                 <td style="width:4%;"> <font style="font-family: Verdana;">Name  </font> </td>
                    <td style="width:8%;" colspan="3"> <?php echo $stname;?> </td>
                 </tr>
                 
                 
                <tr>
                    <td> <font style="font-family: Verdana;">ID  </font> </td>
                    <td colspan="3"> <?php echo $id ?> </td>
                </tr>
                  
                
                <tr>
                    <td> <font style="font-family: Verdana;">Date of Birth  </font> </td>
                    <td colspan="3"> <?php echo $rowdata[2] ?> </td>
                </tr>
                
                <tr>
                    <td> <font style="font-family: Verdana;">Email  </font> </td>
                      <td colspan="3"> <?php echo $rowdata[4]  ?> </td>
                </tr>
                  <?php
                      }
                      ?>
                
                
                  <tr>
                    <td > <font style="font-family: Verdana;"> Mobile No.</font>  </td>
                    <td colspan="3"> <?php echo 'Telephone - '. $row[5]. '   ' ?>
                    
                  </tr>
	
                
                  <tr>
                    <td><font style="font-family: Verdana;"> Office Name</font></td>
                    <td  colspan="3"></td>
                   </tr>
                 
                  <tr>
                    <td> <font style="font-family: Verdana;">Office Code</font></td>
                    <td></td> 
                    <td><font style="font-family: Verdana;"> AMOUNT TO BE PAID</font></td>
                   <td>700</td>
                  </tr>
                
                     
                    
             
                     
               
              
                  
                 
              
                            
                    </td>
                    <td><font style="font-family: Verdana;">Journel No.</font></td>
                    <td></td>
               </tr>  
	<tr>
                    <td><font style="font-family: Verdana;"> Account No.(to be in paid)</font></td>
                    <td  colspan="3">337514252411</td>
                   </tr>
	<tr>
                    <td><font style="font-family: Verdana;"> IFSC Code (to be in paid)</font></td>
                    <td  colspan="3">SBIN00325</td>
                   </tr>
               
               <tr>
                    <td><font style="font-family: Verdana;">Name of cashier</font></td>
                    <td></td>
                    <td><font style="font-family: Verdana;">Signature with seal</font></td>
                    <td><?php echo $row[27] ?></td>
               </tr>  
               
               
           
                           
                            
                 
                       </table></center>
                               </div>
                            </div>
            </div>
        <?php
              }
        ?>
    
            
    </body>
</html>

---------------------------------------------------------------------------------------------------------------------------------------Tear page/Next page------------------------------------------------------------------------------------------------------------------------------


<?php

    session_start();
    error_reporting(0);

$con=mysqli_connect("localhost","root","","oas2");
$q=mysqli_query($con,"select s_name from t_user_data where s_id='".$_SESSION['user']."'");
$n=  mysqli_fetch_assoc($q);
$stname= $n['s_name'];
$id=$_SESSION['user'];

$result = mysqli_query($con,"SELECT * FROM t_user_data WHERE s_id='".$_SESSION['user']."'");
                    
                    while($row = mysqli_fetch_array($result))
                      {
?>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
        
         <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
         <link rel="stylesheet" href="bootstrap/bootstrap-theme.min.css">
       <script src="bootstrap/jquery.min.js"></script>
        <script src="bootstrap/bootstrap.min.js"></script>
        <link type="text/css" rel="stylesheet" href="css/admform.css"></link>
        
        <script type="text/javascript">
            function printpage()
            {
            var printButton = document.getElementById("print");
            printButton.style.visibility = 'hidden';
            window.print()
             printButton.style.visibility = 'visible';
             }
        </script>
        
        
    </head>
    <body>
        <div class="container-fluid">
                            <div class="row">
                               <div class="col-sm-12">
      <center>  <table class="table table-bordered" style="font-family: Verdana">
               
                <tr>
                 <td style="width:3%;"><br><br><img src="./images/right-logo.png" width="100%"> </td>
                 <td style="width:8%;"><center><font style="font-family:Arial Black; font-size:20px;">
                     <br><br>
                    Challan</font></center>
                
                <center><font style="font-family:Verdana; font-size:18px;">
                    (OFFICE PAYMENT CHANNEL) office copy
                    </font></center>
                
                <br>
                <br>
                <center><font style="font-family:Arial Black; font-size:20px;">
                    APPLICATION CODE : 01/2019</font></center>
                </td>
                    <td colspan="2" width="3%" >
                   <?php
                  
                    $picfile_path ='studentpic/';
                    
                    $result1 = mysqli_query($con,"SELECT * FROM t_userdoc where s_id='".$_SESSION['user']."'");
                        
                    while($row1 = mysqli_fetch_array($result1))
                      {                  
                        $picsrc=$picfile_path;
                        
                        echo "<img src='./studentpic/right-logo.png' class='img-thumbnail' width='270px' style='height:180px;'>";
                        echo"<div>";
                      }
                      
                    
                      
                      
                        $resdata = mysqli_query($con,"SELECT * FROM t_user_data WHERE s_id='".$_SESSION['user']."'");
                    
                    while($rowdata = mysqli_fetch_array($resdata))
                      {
                        
                    
                   ?>
                        </td>
                 </tr>       
                 
                 <tr>
                 <td style="width:4%;"> <font style="font-family: Verdana;">Name  </font> </td>
                    <td style="width:8%;" colspan="3"> <?php echo $stname;?> </td>
                 </tr>
                 
                 
                <tr>
                    <td> <font style="font-family: Verdana;">ID  </font> </td>
                    <td colspan="3"> <?php echo $id ?> </td>
                </tr>
                  
                
                <tr>
                    <td> <font style="font-family: Verdana;">Date of Birth  </font> </td>
                    <td colspan="3"> <?php echo $rowdata[2] ?> </td>
                </tr>
                
                <tr>
                    <td> <font style="font-family: Verdana;">Email  </font> </td>
                      <td colspan="3"> <?php echo $rowdata[4]  ?> </td>
                </tr>
                  <?php
                      }
                      ?>
                
                
                  <tr>
                    <td > <font style="font-family: Verdana;"> Mobile No.</font>  </td>
                    <td colspan="3"> <?php echo 'Telephone - '. $row[5]. '   ' ?>
                    
                  </tr>
	
                
                  <tr>
                    <td><font style="font-family: Verdana;"> Office Name</font></td>
                    <td  colspan="3"></td>
                   </tr>
                 
                  <tr>
                    <td> <font style="font-family: Verdana;">Office Code</font></td>
                    <td></td> 
                    <td><font style="font-family: Verdana;"> AMOUNT TO BE PAID</font></td>
                   <td>700</td>
                  </tr>
                
                     
                    
             
                     
               
              
                  
                 
              
                            
                    </td>
                    <td><font style="font-family: Verdana;">Journel No.</font></td>
                    <td></td>
               </tr>  
	<tr>
                    <td><font style="font-family: Verdana;"> Account No.(to be in paid)</font></td>
                    <td  colspan="3">337514252411</td>
                   </tr>
	<tr>
                    <td><font style="font-family: Verdana;"> IFSC Code (to be in paid)</font></td>
                    <td  colspan="3">SBIN00325</td>
                   </tr>
               
               <tr>
                    <td><font style="font-family: Verdana;">Name of cashier</font></td>
                    <td></td>
                    <td><font style="font-family: Verdana;">Signature with seal</font></td>
                    <td><?php echo $row[27] ?></td>
               </tr>  
               
               
           
                           
                            
                 
                       </table></center>
                               </div>
                            </div>
            </div>
        <?php
              }
        ?>
    <center> <input type="submit" id="print" class="toggle btn btn-primary" value="Print" onclick="printpage();"></center>
            
    </body>
</html>



                     