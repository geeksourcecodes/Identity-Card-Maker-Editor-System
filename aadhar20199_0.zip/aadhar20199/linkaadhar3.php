
<?php
session_start();
    
    error_reporting(0);

$con=mysqli_connect("localhost","root","","oas2");
$q=mysqli_query($con,"select s_detid,s_cst from t_user where s_id='".$_SESSION['user']."'");
$n=  mysqli_fetch_assoc($q);
$pan= $n['s_detid'];
$state= $n['s_cst'];
$id=$_SESSION['user'];


$result = mysqli_query($con,"SELECT * FROM t_user WHERE s_id='".$_SESSION['user']."'");
                    
                    while($row = mysqli_fetch_array($result))
                      {
?>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
        <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
         <link rel="stylesheet" href="bootstrap/bootstrap-theme.min.css">
       <script src="bootstrap/jquery.min.js"></script>
        <script src="bootstrap/bootstrap.min.js"></script>
        <link type="text/css" rel="stylesheet" href="css/admform.css"></link>
       
        
        <script type="text/javascript">
            function printpage()
            {
            var printButton = document.getElementById("print");
            printButton.style.visibility = 'hidden';
            window.print()
             printButton.style.visibility = 'visible';
             }
        </script>
    </head>
    <body style="background-image:url(./images/inbg.jpg) ">
      <form id="admincard" action="admincard.php" method="post">
            
          <div class="container-fluid">
                            <div class="row">
                               <div class="col-sm-12">
      <center>  <table class="table table-bordered" style="font-family: Verdana">
                
                
                <center><font style="font-family:Arial Black; font-size:20px;">
                   AADHAR LINK STATUS</font></center>
                </td>
                   
                   </tr>       
                 
                 
                 <tr>
                 <td style="width:4%;"> <font style="font-family: Verdana;">Aadhar Number  </font> </td>
                    <td style="width:8%;" colspan="3"><font style="color:green; margin-left:0px;font-family: Verdana; font-weight: bold">
                     <?php echo $id;?></font> </td>
                 </tr>       
                 
                 
                 <tr>
                 <td style="width:4%;"> <font style="font-family: Verdana;">Pan Card Link ID  </font> </td>
                    <td style="width:8%;" colspan="3"><font style="color:red; margin-left:0px;font-family: Verdana; font-weight: bold">
                     <?php echo $pan;?></font> </td>
                 </tr>

                 
                 <tr>
                 <td style="width:4%;"> <font style="font-family: Verdana;">State </font> </td>
                    <td style="width:8%;" colspan="3"><font style="color:blue; margin-left:0px;font-family: Verdana; font-weight: bold">
                      <?php echo $state;?></font> </td>
                 </tr>
		<tr>
                 <td style="width:4%;"> <font style="font-family: Verdana;">Fill Form  </font> </td>
                    <td style="width:8%;" colspan="3"><font style="font-family: Verdana; font-weight: bold">
                      <li><a  href="PAYCHECK/">Apply for link Aadhar number</a></li></font> </td>
                 </tr>
                 
                
                
                
		

                 </tr>
                <?php
                }
                ?>
                 
                    </table>
                </div>
             </div>
          </div>
          
          
            
          </font>
          
          <center><input type="button" id="print" class="toggle btn btn-primary" value="Print" onclick="printpage();"></center>
      </form>
    </body>
</html>
