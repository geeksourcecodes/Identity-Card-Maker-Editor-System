








<font style="color:Red; margin-left:400px; font-family: Verdana; width:100%; font-size:30px;">
                        <b>Aadhar Number Generated</b> </font>
<h2>
<?php
$conn=mysqli_connect("127.0.0.1:3306","root","","oas2");
// Check connection
if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$sql="select count('user_id') from t_user_data";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_array($result);
echo "$row[0]";
mysqli_close($conn);
?>
<br><br>


<font style="color:Red; margin-left:400px; font-family: Verdana; width:100%; font-size:30px;">
                        <b>Aadhar Card Printed </b> </font>
<h2>
<?php
$conn=mysqli_connect("127.0.0.1:3306","root","","oas2");
// Check connection
if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$sql="select count('user_id') from t_user";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_array($result);
echo "$row[0]";
mysqli_close($conn);
?>


<br><br>


<font style="color:Red; margin-left:400px; font-family: Verdana; width:100%; font-size:30px;">
                        <b>Pan Number Linked Aadhar </b> </font>
<h2>
<?php
$conn=mysqli_connect("127.0.0.1:3306","root","","oas2");
// Check connection
if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$sql="select count('user_id') from paycheck";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_array($result);
echo "$row[0]";
mysqli_close($conn);
?>


<br><br>


<font style="color:Red; margin-left:400px; font-family: Verdana; width:100%; font-size:30px;">
                        <b>Passport Applied/VISA Alloted </b> </font>






<?php
require_once ('connection.php');

$qry = "SELECT `s_id`, `visa` FROM `aai`";
$res = mysqli_query($con,$qry);

?>
<html>

<head>
    <title></title>
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">

</head>

<body>
<div class="container">
	<div class="row">
		<button id="export" class="btn btn-info"></button>
	</div>
    <div class="row">
		<table id="product" class="table table-bordered">
			<thead>
				<tr>
					<th>Passport ID</th>
					<th>VISA Alloted Country</th>
					
					
				</tr>
			</thead>
			<tbody>
				<?php while($row = mysqli_fetch_assoc($res)){ ?>
					<tr>
						<td><?php echo $row['s_id']; ?></td>
						<td><?php echo $row['visa']; ?></td>
						
					</tr>
				<?php } ?>
			</tbody>
		</table>
	</div>
    
</div>

<script src="js/jquery-3.2.0.min.js" type="text/javascript"></script>
<script src="table2excel/src/jquery.table2excel.js" type="text/javascript"></script>

<script>
    $("#export").click(function(){
        $("#product").table2excel({

            // exclude CSS class
            exclude: ".noExl",
            name: "Worksheet Name",
        filename: "product" //do not include extension
    });
    });

</script>

</body>
</html>



                   