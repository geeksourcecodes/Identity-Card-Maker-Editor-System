<center>
<h1> Aadhar Number is not linked with your Pan Number <h1>
<h3> Apply for Aadhar card from nearest enrollment center. And then Link your Aadhar number to Pan Card <h3>
<li><a  href="https://localhost/aadhar/logout.php">Home Page</a></li>