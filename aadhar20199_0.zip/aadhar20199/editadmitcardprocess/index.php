﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Student Information</title>
<link rel="stylesheet" type="text/css" href="Style/viewtablesearch.css" />
</head>
<body>
<center><h1>Correction in Aadhar</h1></center>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a class="addnew" href="Add_Form.php" style="font-face:Khmer OS Battambang; font-size:16px;">ចុចត្រង់នេះដើម្បីបន្ថែម Record ថ្មី</a></font>
	<div class="search">
	<form method="post" action="searchidandname.php">
    <select name="cbosearch">
    	<option>Email_ID</option>
    	<option>Aadhar_Number</option>
        <option>DOB</option>
        <option>Name</option>
    </select>
	<input type="text" name="txtsearch" placeholder="Type to Search" /><input type="submit" name="cmdsearch" value="Search" />
    </form>
    </div>
	<table>
    	<tr>
            <th>Aadhar Number</th>
            
            <th>DOB</th>
            <th>Name</th>
            <th>Father/Husband Name</th>
            <th>Email ID</th>
            <th>Mobile No.</th>
	   <th>Address1</th>
	    <th>Address2</th>
	       <th>District</th>
	    <th>State</th>
             <th>Pincode</th>
		<th>Date of registration</th>
		
            <th>Option</th>
    	</tr>
        <?php
			include "connect.php";
			$i = "select * from t_user_data";
			$h = mysql_query($i);
			while($tr=mysql_fetch_array($h))
			{
		?>
        <tr>
        	<td><?php echo $tr[0]; ?></td>
            
            <td><?php echo $tr[2]; ?></td>
            <td><?php echo $tr[3]; ?></td>
            <td><?php echo $tr[4]; ?></td>
            <td><?php echo $tr[5]; ?></td>
            <td><?php echo $tr[6]; ?></td>
	<td><?php echo $tr[7]; ?></td>
	<td><?php echo $tr[8]; ?></td>
	<td><?php echo $tr[9]; ?></td>
	<td><?php echo $tr[10]; ?></td>
	<td><?php echo $tr[11]; ?></td>
	<td><?php echo $tr[12]; ?></td>
	
            <td align="center"><a href="Delete_Form.php? txtid=<?php echo $tr[0];?>">Delete</a> / <a href="Edit_Form.php? txtid=<?php echo $tr[0];?>">Edit</a> </td>    
        </tr>
        <?php
			}
		?>
		
    </table>
</body>
</html>