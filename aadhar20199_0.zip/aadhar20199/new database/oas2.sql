-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 30, 2019 at 02:43 PM
-- Server version: 5.6.21
-- PHP Version: 5.5.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `oas2`
--

-- --------------------------------------------------------

--
-- Table structure for table `aai`
--

CREATE TABLE IF NOT EXISTS `aai` (
`member_id` int(11) NOT NULL,
  `s_id` text NOT NULL,
  `s_nname` text NOT NULL,
  `fname` text NOT NULL,
  `bgroup` text NOT NULL,
  `dob` text NOT NULL,
  `s_name` text NOT NULL,
  `s_mob` text NOT NULL,
  `adrs` text NOT NULL,
  `pin` text NOT NULL,
  `crime` text NOT NULL,
  `renew` text NOT NULL,
  `indian` text NOT NULL,
  `visa` text NOT NULL,
  `visatime` text NOT NULL,
  `police` text NOT NULL,
  `gender` text NOT NULL,
  `bank` text NOT NULL,
  `sdate` text NOT NULL,
  `edate` text NOT NULL,
  `reason` text NOT NULL,
  `captcha_code` text NOT NULL,
  `date` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aai`
--

INSERT INTO `aai` (`member_id`, `s_id`, `s_nname`, `fname`, `bgroup`, `dob`, `s_name`, `s_mob`, `adrs`, `pin`, `crime`, `renew`, `indian`, `visa`, `visatime`, `police`, `gender`, `bank`, `sdate`, `edate`, `reason`, `captcha_code`, `date`) VALUES
(1, 'AADHAR00008', 'Avinash Kumar', '', '', '', 'Avinash Kumar', '9500000000', '', '', '', '', '', 'NA', '', '', '', 'BIHAR', '', '', '', 'hjasjasjsk', '2019-05-22 10:01:26'),
(2, 'AADHAR00007', 'KAMLESH KUMAR', '', '', '', 'KAMLESH KUMAR', '9100000000', '', '', '', '', '', 'NA', '', '', '', 'MAHARASTRA', '', '', '', 'JHASHJSA', '2019-05-22 20:27:12'),
(3, 'AADHAR00006', 'SANCHIT KUMAR', '', '', '', 'SANCHIT KUMAR', '9100000000', '', '', '', '', '', 'NA', '', '', '', 'BIHAR', '', '', '', 'IHASSAASHJ', '2019-05-24 13:25:50'),
(4, 'AADHAR00011', 'SANCHIT KUMAR', '', '', '', 'SANCHIT KUMAR', '9100000000', '', '', '', '2022', '', 'ENGLAND', '20', '', '', 'BIHAR', '25-05-2019', '14-06-2019', 'TOURISM (CRICKET MATCH)', 'JASJKAS', '2019-05-24 13:28:31'),
(5, 'AADHAR00012', 'RAGHAV SINGH', '	KAMALJEET SINGH', 'O+', '10/04/1994', 'RAGHAV SINGH', '9100000000', 'INDIA WALI GALI  MUMBAI', '414141', 'NO', '2025', '25 BY BIRTH', 'SRILANKA', '6', 'NAVI MUMBAI POLICE STATION CHAUKI', 'Male', 'MAHARASTRA', '30-05-2019', '04-06-2019', 'TOURISM', 'GFAGHAGHSA', '2019-05-24 14:12:25'),
(6, 'AADHAR00021', 'ANKIT ANAND', 'ARUN KUMAR VERMA', 'O+', '02/11/1995', 'ANKIT ANAND', '9414141414', 'R K PURAM ROAD NEAR AMARPALI MALL MUZAFFARPUR', '842002', 'NO', '2025', '26 BY BIRTH', 'MACEDONIA', '10', 'BELA POLICE STATION', 'Male', 'BIHAR', '01-06-2019', '10-06-2019', 'TOURISM', 'aaAAAS', '2019-05-25 22:19:04'),
(7, 'AADHAR00022', 'JITENDAR PATEL', 'SURENDAR PATEL', 'A-', '05/04/1994', 'JITENDAR PATEL', '9147852369', 'MALIGHAT CHOWK CHUNA BHATTI ROAD GALI NO 03 MUZAFFARNAGAR', '400001', 'NO', '2022', '28 BY BIRTH', 'SOUTH KOREA', '50', 'KATHIYA POLICE STATION', 'Male', 'UTTAR PRADESH', '05-06-2019', '24-07-2019', 'BUSINESS TOUR', 'AGFASGH', '2019-05-28 02:44:37'),
(8, 'AADHAR00026', 'VIRAT KHOLI', 'RAHUL KHOLI', 'AB+', '1994-04-01', 'VIRAT KHOLI', '9147852369', 'R K PURAM NEAR METRO STATION ', '100001', 'NO', '2025', '26 BY BIRTH', 'ENGLAND AND WALES', '60', 'R K PURAM POLICE STATION', 'Male', 'NEW DELHI', '05-06-2019', '03-08-2019', 'CRICKET TOUR', 'NASVGSA', '2019-05-29 02:44:14');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
`id` int(11) NOT NULL,
  `username` varchar(32) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `email`) VALUES
(1, 'admin', 'admin', 'omolewastephen@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `banner_posts`
--

CREATE TABLE IF NOT EXISTS `banner_posts` (
`id` int(10) unsigned NOT NULL,
  `title` int(10) unsigned NOT NULL,
  `status` varchar(40) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `banner_posts`
--

INSERT INTO `banner_posts` (`id`, `title`, `status`) VALUES
(1, 1, 'active');

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--

CREATE TABLE IF NOT EXISTS `blogs` (
`id` int(10) unsigned NOT NULL,
  `title` varchar(190) NOT NULL,
  `tags` varchar(40) NOT NULL,
  `content` text NOT NULL,
  `photo` varchar(50) NOT NULL,
  `posted` varchar(40) NOT NULL,
  `date` date DEFAULT NULL,
  `author` varchar(40) DEFAULT NULL,
  `category` varchar(40) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `blogs`
--

INSERT INTO `blogs` (`id`, `title`, `tags`, `content`, `photo`, `posted`, `date`, `author`, `category`) VALUES
(7, 'Register for Aadhar Number', 'Register for Aadhar Number', '<b><font color="#00cc99"></font></b><center><br><div><b style="font-size: 12.855px;"><font color="#00cc99">#You Can Register Here for 10 Digit Aadhar number.</font></b><div style="font-size: 12.855px;"><font color="#00cc99"><b>#After generating 10 Digit Aadhar number . Go to nearest Aadhar enrollment center for submit your documents and biometric to generate your aadhar card.</b></font></div></div><div><font color="#00cc99"><b><br></b></font></div><div><font color="#00cc99"><b>Register Here :&nbsp; &nbsp;&nbsp;<a href="https://localhost/aadhar/admission/signup.php" title="Aadhar Number Generate" target="_blank">Generate Aadahr Number</a></b></font></div></center>', '84967100_1556915111.png', 'publish', '2019-05-03', 'admin', '7'),
(8, 'Apply for Aadhar Card', 'Apply for Aadhar Card', '<font color="#000000">Apply for Aadhar Card&nbsp;</font><div><div><font color="#000000">Get ready your generated 10 digit Aadhar number.</font></div><div><font color="#000000"><br></font></div><div><font color="#000000"># It will cost you Rs.50 rupees for Applying Aadhar card.</font></div><div><font color="#000000">#Pay through Enrollment center by cash or by Card/Internet banking/Wallet/UPI.</font></div><div><font color="#000000">#Biometric will be need to submit you application.</font></div><div><br></div><div><br></div><div><font size="1">Access Granted only for registered enrollment Center</font>:&nbsp; &nbsp;&nbsp;<a href="https://localhost/aadhar/admission/adminlogin.php" title="Apply for aadhar card" target="_blank">Apply for Aadhar Card/Correction</a></div><div><br></div></div>', '97783700_1556938847.jpg', 'publish', '2019-05-04', 'admin', '8'),
(9, 'Download Aadhar Card', 'Download Aadhar Card', 'Download Your Aadhar card using Aadhar number and Registered Email Id<div><br></div><div><br></div><div><font size="1">Aadhar number and email id :&nbsp;</font><a href="https://localhost/aadhar/admission/downloadaadhar.php" title="Download Aadhar Card" target="_blank" style=""><font size="5">Download Aadhar Card</font></a></div>', '15045800_1557074057.jpg', 'publish', '2019-05-05', 'admin', '9'),
(10, 'Link Aadhar Number to Pan Card (Beta version)', 'Link Aadhar Number to Pan Card', 'Link your Aadhar Number to Pan card ( it is mandatory to all users that link you aadhar number to your pan card as per gov. of india rule Act 2016)<div><span style="font-size: 9.64125px; vertical-align: super;">Access granted to all users :</span><font size="3" style="vertical-align: super;">&nbsp;</font><a href="http://localhost/aadhar/admission/linkaadhar2.php" title="Link Aadhar Number to Pan Card (Beta version)" target="_blank" style="background-color: rgb(255, 255, 255);"><font size="4">Link Aadhar Number to Pan Number</font></a><br></div><div style="font-size: 12.855px;"><br></div>', '54808900_1557177447.jpg', 'draft', '2019-05-07', 'admin', '10'),
(11, 'Check Aadhar -Pan Link Status', 'Check Aadhar -Pan Link Status', 'You Can Check your linking Status of your Aadhar number to Pan number<div><br></div><div><sup>Access granted to all users:&nbsp;<a href="https://localhost/aadhar/admission/panstatus.php" title="Aadhar-Pan Link Status" target="_blank"><font size="5">Check Aadhar - Pan Link Status</font></a></sup></div>', '13754500_1557409986.gif', 'draft', '2019-05-09', 'admin', '11'),
(12, 'Survey Officer Login', 'Survey Officer Login', 'Login For Survey Officer to Verify Address of citizen and DoB.<div>Step 1: Citizen has to Generate Aadhar Number.</div><div>Step 2: Citizen has to login through Aadhar Number and P-OTP&nbsp; to schedule a appointment for verification.</div><div>Step 3: Survey Officer came to that address and check all details and verify the citizen by whom aadhar is applied</div><div>Step 4: After Verification A verification letter is generated online for citizen (obtained by login through Aadhar number and P-OTP). This Letter is mandatory for applyig Aadhar card .</div><div>Step 5: Go to the nearest Aadhar Enrollment Center to apply aadhar card with relevent documents :</div><div>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; a) Address Proof</div><div>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; b)DOB Proof</div><div>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; c) Aadhar Verification Letter</div><div>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; d)Verifcation Schedule Application</div><div>Step 6: Pay Rs.50 for applying Aadhar card through Cash or Challan</div><div>Step 7 : Ready for Biometrics like retina , thumb,face</div><div>Step 8: Download Aadhar Card</div><div><br></div><div><br></div><div>&nbsp; Login Survey Officer :&nbsp;<a href="https://localhost/aadhar/admission/appoint/admin/admin_login.php" title="Survey Officer Login" target="_blank"><font size="4">Survey Offcier Login</font></a></div>', '37088700_1559219493.jpg', 'draft', '2019-05-30', 'admin', '12'),
(13, 'How To Apply Aadhar Card ?', 'How To Apply Aadhar Card ?', '<div>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<b><font color="#ff0000"> <font size="3">How to Apply For New Aadhar Card</font></font></b></div><div><br></div><div><br></div><div>Step 1: Citizen has to Generate Aadhar Number.</div><div>Step 2: Citizen has to login through Aadhar Number and P-OTP&nbsp; to schedule a appointment for verification.</div><div>Step 3: Survey Officer came to that address and check all details and verify the citizen by whom aadhar is applied</div><div>Step 4: After Verification A verification letter is generated online for citizen (obtained by login through Aadhar number and P-OTP). This Letter is mandatory for applyig Aadhar card .</div><div>Step 5: Go to the nearest Aadhar Enrollment Center to apply aadhar card with relevent documents :</div><div>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; a) Address Proof</div><div>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; b)DOB Proof</div><div>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; c) Aadhar Verification Letter</div><div>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; d)Verifcation Schedule Application</div><div>Step 6: Pay Rs.50 for applying Aadhar card through Cash or Challan</div><div>Step 7 : Ready for Biometrics like retina , thumb,face</div><div>Step 8: Download Aadhar Card</div>', '78975600_1559219986.jpg', 'publish', '2019-05-30', 'admin', '13');

-- --------------------------------------------------------

--
-- Table structure for table `blog_categories`
--

CREATE TABLE IF NOT EXISTS `blog_categories` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(40) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `blog_categories`
--

INSERT INTO `blog_categories` (`id`, `name`) VALUES
(7, 'Register for Aadhar number'),
(8, 'Apply for Aadhar Card'),
(9, 'Download Aadhar Card'),
(10, 'Link Aadhar Number to Pan Card'),
(11, 'Check Aadhar-Pan Link Status'),
(12, 'Survey Officer login'),
(13, 'How to apply aadhar card ?');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
`contact_id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `editors_choice`
--

CREATE TABLE IF NOT EXISTS `editors_choice` (
`id` int(10) unsigned NOT NULL,
  `blog` int(10) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `editors_choice`
--

INSERT INTO `editors_choice` (`id`, `blog`) VALUES
(2, 3),
(1, 4),
(3, 7);

-- --------------------------------------------------------

--
-- Table structure for table `links`
--

CREATE TABLE IF NOT EXISTS `links` (
`id` int(10) unsigned NOT NULL,
  `facebook` varchar(40) DEFAULT NULL,
  `twitter` varchar(40) DEFAULT NULL,
  `googleplus` varchar(40) DEFAULT NULL,
  `pinterest` varchar(40) DEFAULT NULL,
  `dribble` varchar(40) DEFAULT NULL,
  `comments_script` text,
  `sharing_script` text,
  `javascript` text
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `links`
--

INSERT INTO `links` (`id`, `facebook`, `twitter`, `googleplus`, `pinterest`, `dribble`, `comments_script`, `sharing_script`, `javascript`) VALUES
(1, 'http://www.facebook.com', 'http://www.twitter.com', 'http://www.plus.google.com', 'http://www.pinterest.com', 'http://www.dribble.com', '<div class="fb-comments container" data-href="http://www.uoecu.org/newsview.php?id=<?php echo $row[''id''];?>" data-numposts="20" width="100%"></div>', '<div class="addthis_sharing_toolbox"></div>', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `locals`
--

CREATE TABLE IF NOT EXISTS `locals` (
`local_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL,
  `local_name` varchar(50) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=738 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `locals`
--

INSERT INTO `locals` (`local_id`, `state_id`, `local_name`) VALUES
(2, 2, 'RURAL'),
(1, 1, 'URBAN');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE IF NOT EXISTS `members` (
`id` int(11) NOT NULL,
  `s_id` varchar(30) NOT NULL,
  `s_dob` varchar(30) NOT NULL,
  `s_name` text NOT NULL,
  `s_ad` text NOT NULL,
  `s_date` text NOT NULL,
  `s_time` text NOT NULL,
  `f_name` text NOT NULL,
  `m_name` text NOT NULL,
  `s_sex` text NOT NULL,
  `s_padr` text NOT NULL,
  `s_pst` text NOT NULL,
  `s_ppin` text NOT NULL,
  `s_catg` text NOT NULL,
  `s_branch` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `s_id`, `s_dob`, `s_name`, `s_ad`, `s_date`, `s_time`, `f_name`, `m_name`, `s_sex`, `s_padr`, `s_pst`, `s_ppin`, `s_catg`, `s_branch`) VALUES
(17, 'CUTM00003', '9/8/2015', 'Archana Kumari', 'D.A.V MALIGHAT MUZAFFARPUR\r\nBIHAR 842001', '6-Apr-19', '12:00PM - 2:00 PM (AFTERNOON SHIFT)', 'Madhusudan Mahato', 'SUJATA SINGH', 'Female', 'Jamshedpur', 'Jharkhand', '831004', 'GEN', 'COMPUTER SCIENCE AND ENG'),
(18, 'CUTM00008', '10/15/2015', 'Ankita Saigal', 'KENDRIYA VIDYALA ,NEAR KAHBAR MUZAFFARPUR,BIHAR  08256', '7-Apr-19', '12:00PM - 2:00 PM (AFTERNOON SHIFT)', 'Rakesh Saigal', '', 'Female', 'Near Meera Hotel', 'Odisha', '768028', 'GEN', 'ELECTRICAL AND ELECTRONICS ENG'),
(19, 'CUTM00012', '1/1/1997', 'SURAJ KUMAR', 'KENDRIYA VIDYALA ,NEAR KAHBAR MUZAFFARPUR,BIHAR  08257', '8-Apr-19', '12:00PM - 2:00 PM (AFTERNOON SHIFT)', 'RAHUL', '', '', 'BIHAR', 'Bihar', '842001', '', 'ELECTRONICS AND COMM ENG'),
(20, 'CUTM00013', '3/2/1993', 'rahuram', 'KENDRIYA VIDYALA ,NEAR KAHBAR MUZAFFARPUR,BIHAR  08258', '9-Apr-19', '12:00PM - 2:00 PM (AFTERNOON SHIFT)', 'rahuram@gmail.com', '', 'Male', 'HOMELESS CHOWK KHABSRA ROAD', 'Bihar', '842001', '', ''),
(21, 'CUTM00014', '11/6/1996', 'rajesh singh', 'DAV MALIGHAT, NEAR BMP-6, MUZAFFARPUR,BIHAR 842001', '10-Apr-19', '12:00PM - 2:00 PM (AFTERNOON SHIFT)', 'rajesh@gmail.com', '', 'Male', 'HOMELESS CHOWK KHABRA ROAD', 'Bihar', '842001', '', ''),
(22, 'CUTM00015', '11/21/2018', 'RAMESH', 'DAV MALIGHAT, NEAR BMP-6, MUZAFFARPUR,BIHAR 842002', '11-Apr-19', '12:00PM - 2:00 PM (AFTERNOON SHIFT)', 'RAMESH@GMAIL.COM', '', 'Male', 'BADSHANAGAR, SITAPUR ROAD', 'UTTAR PRADESH', '412520', '', ''),
(23, 'CUTM00016', '1/4/2000', 'ROCKSTAR', 'DAV MALIGHAT, NEAR BMP-6, MUZAFFARPUR,BIHAR 842003', '12-Apr-19', '12:00PM - 2:00 PM (AFTERNOON SHIFT)', 'SANCHIT', '', 'Male', 'HOMELESS CHOWK KHABRA ROAD', 'Bihar', '842001', '', ''),
(24, 'CUTM00017', '2/5/2008', 'VIKAS SINGH', 'DAV MALIGHAT, NEAR BMP-6, MUZAFFARPUR,BIHAR 842004', '13-Apr-19', '12:00PM - 2:00 PM (AFTERNOON SHIFT)', 'VIKASH', '', 'Male', 'BADSHANAGAR, SITAPUR ROAD', 'UTTAR PRADESH', '412520', '', ''),
(25, 'CUTM00018', '7/11/2006', 'KAMLESH', 'DAV MALIGHAT, NEAR BMP-6, MUZAFFARPUR,BIHAR 842005', '14-Apr-19', '12:00PM - 2:00 PM (AFTERNOON SHIFT)', 'KAMLESH', '', 'Male', '45', '88', '98', '95', '99'),
(26, 'CUTM00019', '1/1/1997', 'SANCHIT KUMAR', 'DAV MALIGHAT, NEAR BMP-6, MUZAFFARPUR,BIHAR 842006', '15-Apr-19', '12:00PM - 2:00 PM (AFTERNOON SHIFT)', 'SANCHIT', 'CHINTA DEVI', 'Male', 'HOMELESS CHOWK KHABRA ROAD', 'BIHAR', '842001', 'OBC', 'ELECTRICAL AND ELECTRONICS ENG'),
(27, 'CUTM00020', '1/10/1997', 'SANCHIT KUMAR', 'DAV MALIGHAT, NEAR BMP-6, MUZAFFARPUR,BIHAR 842007', '16-Apr-19', '12:00PM - 2:00 PM (AFTERNOON SHIFT)', 'SANCHIT', '', 'Male', 'HOMELESS CHOWK KHABRA ROAD', 'BIHAR', '842001', 'OBC', 'COMPUTER SCIENCE AND ENG'),
(28, 'CUTM00021', '3/15/1994', 'NARENDRA MODI', 'DAV MALIGHAT, NEAR BMP-6, MUZAFFARPUR,BIHAR 842008', '17-Apr-19', '12:00PM - 2:00 PM (AFTERNOON SHIFT)', 'SANCHIT', '', '', 'HOMELESS CHOWK KHABRA ROAD', 'BIHAR', '842001', 'OBC', 'ELECTRONICS AND COMM ENG'),
(29, 'CUTM00022', '3/19/2015', 'KUMAR RAHUL', 'DAV MALIGHAT, NEAR BMP-6, MUZAFFARPUR,BIHAR 842009', '18-Apr-19', '12:00PM - 2:00 PM (AFTERNOON SHIFT)', 'SANCHIT', '', 'Male', 'HOMELESS CHOWK KHABRA ROAD', 'Bihar', '842001', 'ST', 'COMPUTER SCIENCE AND ENG'),
(30, 'CUTM00023', '2/28/1995', 'SANCHIT KUMAR', 'DAV MALIGHAT, NEAR BMP-6, MUZAFFARPUR,BIHAR 842010', '19-Apr-19', '12:00PM - 2:00 PM (AFTERNOON SHIFT)', 'SANCHIT', '', 'Male', 'HOMELESS CHOWK KHABRA ROAD', 'Bihar', '842001', 'ST', 'COMPUTER SCIENCE AND ENG');

-- --------------------------------------------------------

--
-- Table structure for table `membership_grouppermissions`
--

CREATE TABLE IF NOT EXISTS `membership_grouppermissions` (
`permissionID` int(10) unsigned NOT NULL,
  `groupID` int(11) DEFAULT NULL,
  `tableName` varchar(100) DEFAULT NULL,
  `allowInsert` tinyint(4) DEFAULT NULL,
  `allowView` tinyint(4) NOT NULL DEFAULT '0',
  `allowEdit` tinyint(4) NOT NULL DEFAULT '0',
  `allowDelete` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `membership_grouppermissions`
--

INSERT INTO `membership_grouppermissions` (`permissionID`, `groupID`, `tableName`, `allowInsert`, `allowView`, `allowEdit`, `allowDelete`) VALUES
(1, 2, 'titles', 1, 3, 3, 3),
(2, 2, 'links', 1, 3, 3, 3),
(3, 2, 'blog_categories', 1, 3, 3, 3),
(4, 2, 'blogs', 1, 3, 3, 3),
(5, 2, 'banner_posts', 1, 3, 3, 3),
(6, 2, 'editors_choice', 1, 3, 3, 3),
(32, 3, 'titles', 0, 0, 0, 0),
(33, 3, 'links', 0, 0, 0, 0),
(34, 3, 'blog_categories', 0, 3, 0, 0),
(35, 3, 'blogs', 1, 1, 1, 1),
(36, 3, 'editors_choice', 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `membership_groups`
--

CREATE TABLE IF NOT EXISTS `membership_groups` (
`groupID` int(10) unsigned NOT NULL,
  `name` varchar(20) DEFAULT NULL,
  `description` text,
  `allowSignup` tinyint(4) DEFAULT NULL,
  `needsApproval` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `membership_groups`
--

INSERT INTO `membership_groups` (`groupID`, `name`, `description`, `allowSignup`, `needsApproval`) VALUES
(1, 'anonymous', 'Anonymous group created automatically on 2018-04-26', 0, 0),
(2, 'Admins', 'Admin group created automatically on 2018-04-26', 0, 1),
(3, 'authors', 'contains all the guest authors', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `membership_userpermissions`
--

CREATE TABLE IF NOT EXISTS `membership_userpermissions` (
`permissionID` int(10) unsigned NOT NULL,
  `memberID` varchar(20) NOT NULL,
  `tableName` varchar(100) DEFAULT NULL,
  `allowInsert` tinyint(4) DEFAULT NULL,
  `allowView` tinyint(4) NOT NULL DEFAULT '0',
  `allowEdit` tinyint(4) NOT NULL DEFAULT '0',
  `allowDelete` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `membership_userrecords`
--

CREATE TABLE IF NOT EXISTS `membership_userrecords` (
`recID` bigint(20) unsigned NOT NULL,
  `tableName` varchar(100) DEFAULT NULL,
  `pkValue` varchar(255) DEFAULT NULL,
  `memberID` varchar(20) DEFAULT NULL,
  `dateAdded` bigint(20) unsigned DEFAULT NULL,
  `dateUpdated` bigint(20) unsigned DEFAULT NULL,
  `groupID` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `membership_userrecords`
--

INSERT INTO `membership_userrecords` (`recID`, `tableName`, `pkValue`, `memberID`, `dateAdded`, `dateUpdated`, `groupID`) VALUES
(1, 'titles', '1', 'admin', 1524766759, 1559219703, 2),
(2, 'links', '1', 'admin', 1524766827, 1557344141, 2),
(9, 'banner_posts', '1', 'admin', 1524779492, 1524779492, 2),
(13, 'editors_choice', '1', 'admin', 1524799889, 1524799889, 2),
(14, 'editors_choice', '2', 'admin', 1524799903, 1524799903, 2),
(18, 'blog_categories', '7', 'admin', 1556914658, 1557104309, 2),
(19, 'blog_categories', '8', 'admin', 1556914692, 1556914692, 2),
(20, 'blogs', '7', 'admin', 1556915111, 1557809087, 2),
(21, 'blogs', '8', 'admin', 1556938848, 1557809517, 2),
(22, 'blog_categories', '9', 'admin', 1557072815, 1557072815, 2),
(23, 'blogs', '9', 'admin', 1557074057, 1557809651, 2),
(24, 'editors_choice', '3', 'admin', 1557075516, 1557075516, 2),
(25, 'blog_categories', '10', 'admin', 1557177170, 1557177170, 2),
(26, 'blogs', '10', 'admin', 1557177447, 1557809788, 2),
(27, 'blog_categories', '11', 'admin', 1557409429, 1557409429, 2),
(28, 'blogs', '11', 'admin', 1557409986, 1557810102, 2),
(29, 'blog_categories', '12', 'admin', 1559218684, 1559218684, 2),
(30, 'blogs', '12', 'admin', 1559219493, 1559219493, 2),
(31, 'blog_categories', '13', 'admin', 1559219800, 1559219800, 2),
(32, 'blogs', '13', 'admin', 1559219986, 1559219986, 2);

-- --------------------------------------------------------

--
-- Table structure for table `membership_users`
--

CREATE TABLE IF NOT EXISTS `membership_users` (
  `memberID` varchar(20) NOT NULL,
  `passMD5` varchar(40) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `signupDate` date DEFAULT NULL,
  `groupID` int(10) unsigned DEFAULT NULL,
  `isBanned` tinyint(4) DEFAULT NULL,
  `isApproved` tinyint(4) DEFAULT NULL,
  `custom1` text,
  `custom2` text,
  `custom3` text,
  `custom4` text,
  `comments` text,
  `pass_reset_key` varchar(100) DEFAULT NULL,
  `pass_reset_expiry` int(10) unsigned DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `membership_users`
--

INSERT INTO `membership_users` (`memberID`, `passMD5`, `email`, `signupDate`, `groupID`, `isBanned`, `isApproved`, `custom1`, `custom2`, `custom3`, `custom4`, `comments`, `pass_reset_key`, `pass_reset_expiry`) VALUES
('admin', '21232f297a57a5a743894a0e4a801fc3', 'ronniengoda@gmail.com', '2018-04-26', 2, 0, 1, NULL, NULL, NULL, NULL, 'Admin member created automatically on 2018-04-26\nRecord updated automatically on 2018-04-27', NULL, NULL),
('etemesi', '827ccb0eea8a706c4c34a16891f84e7b', 'etemesi@gmail.com', '2018-04-27', 3, 0, 1, 'philiiip etemesi', 'nairobi,kenya', 'nairobi', 'kenya', 'member signed up through the registration form.', NULL, NULL),
('guest', NULL, NULL, '2018-04-26', 1, 0, 1, NULL, NULL, NULL, NULL, 'Anonymous member created automatically on 2018-04-26', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `olevel`
--

CREATE TABLE IF NOT EXISTS `olevel` (
`id` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `olevel`
--

INSERT INTO `olevel` (`id`, `subject`) VALUES
(1, 'Mathematics'),
(2, 'English Language'),
(3, 'Geography'),
(4, 'Further Mathematics'),
(5, 'Economics'),
(6, 'Commerce'),
(7, 'Agricultural Studies'),
(8, 'Physics'),
(9, 'Chemistry'),
(10, 'Yoruba'),
(11, 'Government'),
(12, 'Biology');

-- --------------------------------------------------------

--
-- Table structure for table `olevel_upload`
--

CREATE TABLE IF NOT EXISTS `olevel_upload` (
`id` int(11) NOT NULL,
  `std_id` varchar(50) NOT NULL,
  `path` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE IF NOT EXISTS `pages` (
`id` int(11) NOT NULL,
  `menu_name` varchar(32) NOT NULL,
  `position` int(3) NOT NULL,
  `content` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `menu_name`, `position`, `content`) VALUES
(1, 'Schedule For Aadhar Verification', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `page_hits`
--

CREATE TABLE IF NOT EXISTS `page_hits` (
  `page` varchar(255) NOT NULL,
  `count` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `page_hits`
--

INSERT INTO `page_hits` (`page`, `count`) VALUES
('', 1),
('Apply for Aadhar Card', 38),
('Benefits of livig in this world', 6),
('Check Aadhar -Pan Link Status', 19),
('Download Aadhar Card', 36),
('Link Aadhar Number to Pan Card', 1),
('Link Aadhar Number to Pan Card (Beta version)', 27),
('Register for Aadhar Number', 29),
('The challanges of being a writter', 6),
('The future of web developement on earth', 19),
('The subtle art of not giving a fuck-Mark Manson', 22),
('Why i ventured into writting as a proffesion', 2);

-- --------------------------------------------------------

--
-- Table structure for table `paycheck`
--

CREATE TABLE IF NOT EXISTS `paycheck` (
`member_id` int(11) NOT NULL,
  `s_id` text NOT NULL,
  `s_nname` text NOT NULL,
  `s_name` text NOT NULL,
  `s_mob` text NOT NULL,
  `bank` text NOT NULL,
  `captcha_code` text NOT NULL,
  `date` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `paycheck`
--

INSERT INTO `paycheck` (`member_id`, `s_id`, `s_nname`, `s_name`, `s_mob`, `bank`, `captcha_code`, `date`) VALUES
(1, '0', '', '0', '0', '', '', '0000-00-00'),
(2, 'CUTM00029', '', 'Sanchit Kumar', '2147483647', 'Credit Card', 'Vjw9GD', '2019-04-18'),
(3, 'CUTM00030', '', 'JASSJSAD', '2147483647', 'BHIM UPI', 'WLNSz8', '2019-04-18'),
(4, 'CUTM00031', '', 'Sanchit Kumar', '2147483647', 'wallet', '3W6VDb', '2019-04-18'),
(5, 'cshagsghsh', '', 'nas', '0', 'ATM cum Debit Card', 'ssas', '2019-04-18'),
(6, 'CUTM000350', '', 'Sanchit Kumar', '2147483647', 'Net banking', 'zb35LK', '2019-04-18'),
(7, 'CUTM00100', '', 'adshsdh', '2147483647', 'Net banking', '8hny38', '2019-04-18'),
(8, 'CUTM00001', '', 'Sanchit Kumar', '2147483647', 'BHIM UPI', '2gvggfgf', '2019-04-18'),
(9, 'CUTM00036', '', 'SHIVANI SINGH', '2147483647', 'ATM cum Debit Card', '4DMxwP', '2019-04-19'),
(10, 'CUTM00037', '', 'ABHIHSKE', '2020202222', 'other', 'q8RtRB', '2019-04-19'),
(11, 'CUTM00038', '', 'SAHRUK KHAN', '2147483647', 'ATM cum Debit Card', 'HGASGHAS', '2019-04-19'),
(12, 'AADHAR00008', '', 'DOHPK0235B', '0', 'BIHAR', 'KXSSA', '2019-05-07 11:18:57'),
(13, 'AADHAR00008', '', 'DHBNK0000M', 'DE00000003', 'MEGHALAYA', 'ssas', '2019-05-07 11:24:27'),
(14, 'AADHAR00008', 'SANCHIT', 'HSJDSJD45', 'DE00000003', 'UTTARAKHAND', 'ASSSAS', '2019-05-08 08:09:37'),
(15, 'AADHAR00007', 'KUMAR SHANI', 'DOHBB7876T', 'DE00000002', 'MAHARASTRA', 'SAASSA', '2019-05-08 08:38:12'),
(16, 'AADHAR00011', 'SANCHIT KUMAR', 'HOJPK8909I', 'DE00000006', 'NEW DELHI', 'ASAAS', '2019-05-09 06:37:08'),
(17, 'AADHAR00012', 'RAGHAV', 'AAAA8888I', 'DE00000007', 'MAHARASTRA', 'JKA', '2019-05-09 09:44:44'),
(18, 'AADHAR00013', 'KISHLAY RANKAN', 'DOHNK7452L', 'DE00000008', 'BIHAR', 'ASAS', '2019-05-10 12:44:50'),
(19, 'AADHAR00014', 'BABA RAM DEV', 'AADF0251K', 'DE00000009', 'UTTAR PRADESH', 'HGADSGH', '2019-05-11 03:34:38'),
(20, 'AADHAR00009', 'SHENHA SINGH', 'DHOPK1251L', 'DE00000004', 'ODISHA', '9Jv6sS', '2019-05-13 21:24:03'),
(21, 'AADHAR00015', 'RAVAN SINGH', 'DHJK8934K', 'DE00000011', 'MAHARASTRA', 'JBASH', '2019-05-14 10:17:49'),
(22, 'AADHAR00010', 'Avinash Kumar', 'DHKLK8888P', 'DE00000005', 'BIHAR', 'JHAJGAS', '2019-05-21 09:18:23');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE IF NOT EXISTS `payment` (
`id` int(11) NOT NULL,
  `s_id` varchar(30) NOT NULL,
  `f_pay` varchar(30) NOT NULL,
  `s_date` text NOT NULL,
  `s_tran` text NOT NULL,
  `s_form` text NOT NULL,
  `s_email` text NOT NULL,
  `s_phone` text NOT NULL,
  `s_amount` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `s_id`, `f_pay`, `s_date`, `s_tran`, `s_form`, `s_email`, `s_phone`, `s_amount`) VALUES
(39, 'CUTM00028', 'MOJO9311405N34339625', '11/3/2019 13:07', 'Success', 'Admission form 2019', 'sanchit.muz@gmail.com', '8789254146', '9');

-- --------------------------------------------------------

--
-- Table structure for table `programs`
--

CREATE TABLE IF NOT EXISTS `programs` (
`id` int(11) NOT NULL,
  `type` varchar(30) NOT NULL,
  `code` varchar(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `num_semester` varchar(10) NOT NULL,
  `duration` varchar(10) NOT NULL,
  `eligibility` text NOT NULL,
  `max_duration` varchar(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `programs`
--

INSERT INTO `programs` (`id`, `type`, `code`, `name`, `description`, `num_semester`, `duration`, `eligibility`, `max_duration`) VALUES
(1, 'Authority', 'KARVY', 'KARVY ( SCREENING DEPARTMENT )', 'KARVY ( SCREENING DEPARTMENT )', '0', '0', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `ref`
--

CREATE TABLE IF NOT EXISTS `ref` (
`id` int(11) NOT NULL,
  `ref_number` varchar(255) NOT NULL,
  `used` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ref`
--

INSERT INTO `ref` (`id`, `ref_number`, `used`) VALUES
(1, 'gtp234744636373', 0),
(2, 'gtp234744637896', 0);

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE IF NOT EXISTS `states` (
  `state_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`state_id`, `name`) VALUES
(1, 'ANDRA PRADESH'),
(2, 'ASSAM'),
(3, 'BIHAR'),
(4, 'WEST BENGAL'),
(5, 'ANDRR PRADESH'),
(6, 'ARUNACHAL PRADESH'),
(7, 'SIKKIM'),
(8, 'MIZORAM'),
(9, 'TRIPURA'),
(10, 'MEGHALAYA'),
(11, 'MANIPUR'),
(12, 'PANJAB'),
(13, 'UTTAR PRADESH'),
(14, 'MADHAYA PRADESH'),
(15, 'MAHARASTRA'),
(16, 'GUJRAT'),
(17, 'RAJASTHAN'),
(18, 'HARIYANA'),
(19, 'JAMMU AND KASHMIR'),
(20, 'UTTARKHAND'),
(21, 'CHANDIGADH'),
(22, 'KERALA'),
(23, 'CHENNAI'),
(24, 'KARNATAKA'),
(25, 'TELENGANA'),
(26, 'GOA'),
(27, 'PUDUCHERRY'),
(28, 'ANDOMAN NICOBAR'),
(29, 'LAKSHDEEP'),
(30, 'ODISHA');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE IF NOT EXISTS `students` (
`id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `surname` varchar(255) COLLATE utf8_bin NOT NULL,
  `jambreg` varchar(40) COLLATE utf8_bin NOT NULL,
  `program` varchar(30) COLLATE utf8_bin NOT NULL,
  `h_address` text COLLATE utf8_bin NOT NULL,
  `gender` varchar(30) COLLATE utf8_bin NOT NULL,
  `mstatus` varchar(30) COLLATE utf8_bin NOT NULL,
  `state_id` int(11) NOT NULL,
  `dob` varchar(255) COLLATE utf8_bin NOT NULL,
  `local` varchar(255) COLLATE utf8_bin NOT NULL,
  `email` varchar(30) COLLATE utf8_bin NOT NULL,
  `phone` varchar(255) COLLATE utf8_bin NOT NULL,
  `course` int(11) NOT NULL,
  `exam` varchar(255) COLLATE utf8_bin NOT NULL,
  `jamb_path` varchar(30) COLLATE utf8_bin NOT NULL,
  `olevel_path` varchar(30) COLLATE utf8_bin NOT NULL,
  `passport` varchar(30) COLLATE utf8_bin NOT NULL,
  `ref_number` varchar(255) COLLATE utf8_bin NOT NULL,
  `admission_status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `name`, `surname`, `jambreg`, `program`, `h_address`, `gender`, `mstatus`, `state_id`, `dob`, `local`, `email`, `phone`, `course`, `exam`, `jamb_path`, `olevel_path`, `passport`, `ref_number`, `admission_status`) VALUES
(1, 'Sanchit', 'Kumar', 'AADHAR00002', 'HND', 'HOMELESS CHOWK ,KHABRA ROAD\r\n', 'M', 'single', 14, '01/05/1996', '737', 'sanchit.muz@gmail.com', '9100000000', 1, 'wassce may/june', 'uploads/APP.jpg', 'olevel/RATION CARD.jpg', 'passport/FACE.jpg', 'AADHAR00002', 1),
(2, 'Sanchit', 'Kumar', 'AADHAR00004', 'NEXTDAY', 'HOMELESS CHOWK ,KHABRA ROAD\r\nMuzaffarpur', 'M', 'single', 3, '10/04/1994', '2', 'sanchit.muz@gmail.com', '9504294889', 2, 'neco', 'uploads/RATION CARD.jpg', 'olevel/RATION CARD.jpg', 'passport/FACE.jpg', 'AADHAR00004', 0),
(3, 'RABBI', 'KUMAR', 'AADHAR00005', 'NEXTDAY', 'MALIGHAT RAMBHAG CHOWK MUZAFFARPUR', 'M', 'single', 15, '05/05/1998', '2', 'RABHI@GMAIL.COM', '9126969696', 0, 'wassce may/june', 'uploads/RATION CARD.jpg', 'olevel/FACE.jpg', 'images/no_image.jpg', 'AADHAR00005', 1),
(4, 'SHIVANI', 'SINGH', 'AADHAR00006', 'NEXTNEXTDAY', 'MALIGHAT CHUNA BHATI GALI KOLKATTA', 'F', 'single', 22, '05/06/1996', '2', 'SHIVANI@GMAIL.COM', '9141414144', 1, 'neco', 'images/APP.jpg', 'images/THUMBL.jpg', 'images/FACE.jpg', 'AADHAR00006', 1),
(5, 'Sanchit', 'Kumar', 'AADHAR00008', 'NEXTDAY', 'HOMELESS CHOWK ,KHABRA ROAD\r\nMuzaffarpur', 'M', 'single', 3, '01/02/1996', '1', 'sanchit.muz@gmail.com', '9504294889', 1, 'Birth Certificate By Munispality', 'images/APP.jpg', 'images/APP.jpg', 'images/PIC.jpg', 'AADHAR00008', 1),
(6, 'JITENDRA ', 'PATEL', 'AADHAR00022', 'NEXTDAY', 'MALIGHAT CHOWK CHUNA BHATTI ROAD GALI NO 03 MUZAFFARNAGAR 400001', 'M', 'single', 13, '04/05/1994', '1', 'JITENINDIA@GMIL.COM', '9147852369', 1, 'Voter ID', 'images/RATION CARD.jpg', 'images/RATION CARD.jpg', 'images/download.jpg', 'AADHAR00022', 1),
(7, 'VIRAT', 'KHOLI', 'AADHAR00026', 'NEXTDAY', 'R.K PURAM NEAR METRO STATION NEW DELHI ', 'M', 'married', 27, '1994-04-01', '1', 'VIRAT@VIRAT.COM', '9147852369', 1, 'Voter ID', 'images/RATION CARD.jpg', 'images/RATION CARD.jpg', 'images/vurat.jpg', 'AADHAR00026', 1);

-- --------------------------------------------------------

--
-- Table structure for table `titles`
--

CREATE TABLE IF NOT EXISTS `titles` (
`id` int(10) unsigned NOT NULL,
  `website_name` varchar(40) DEFAULT NULL,
  `tagline` varchar(40) DEFAULT NULL,
  `icon` varchar(40) DEFAULT NULL,
  `keywords` varchar(220) DEFAULT NULL,
  `short_description` varchar(200) DEFAULT NULL,
  `bannertext1` varchar(150) DEFAULT NULL,
  `bannertext2` varchar(150) DEFAULT NULL,
  `bannertext3` varchar(150) DEFAULT NULL,
  `bannertext4` varchar(150) DEFAULT NULL,
  `detailed_description` text,
  `address` varchar(40) DEFAULT NULL,
  `email` varchar(80) DEFAULT NULL,
  `phone` varchar(40) DEFAULT NULL,
  `googlemap` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `titles`
--

INSERT INTO `titles` (`id`, `website_name`, `tagline`, `icon`, `keywords`, `short_description`, `bannertext1`, `bannertext2`, `bannertext3`, `bannertext4`, `detailed_description`, `address`, `email`, `phone`, `googlemap`) VALUES
(1, 'Aadhar Ecosystem', 'Aadhar Ecosystem', '82230700_1557343240.png', 'Aadhar, about aadhar', 'What is Aadhaar?', NULL, NULL, NULL, NULL, 'How to Obtain Aadhar\n\r\nStep 1: Citizen has to Generate Aadhar Number.\n\r\nStep 2: Citizen has to login through Aadhar Number and P-OTP  to schedule a appointment for verification.\n\r\nStep 3: Survey Officer came to that address and check all details and verify the citizen by whom aadhar is applied\n\r\nStep 4: After Verification A verification letter is generated online for citizen (obtained by login through Aadhar number and P-OTP). This Letter is mandatory for applyig Aadhar card .\n\r\nStep 5: Go to the nearest Aadhar Enrollment Center to apply aadhar card with relevent documents :\n\r\n                          a) Address Proof\n\r\n                          b)DOB Proof\n\r\n                          c) Aadhar Verification Letter\n\r\n                          d)Verifcation Schedule Application\n\r\nStep 6: Pay Rs.50 for applying Aadhar card through Cash or Challan\n\r\nStep 7 : Ready for Biometrics like retina , thumb,face\n\r\nStep 8: Download Aadhar Card\n', 'New delhi, India', 'info@fantasticblog.com', '910000000000', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d100949.24429313939!2d-122.44206553967531!3d37.75102885910819!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80859a6d00690021%3A0x4a501367f076adff!2sSan+Francisco%2C+CA%2C+USA!5e0!3m2!1sen!2sin!4v1');

-- --------------------------------------------------------

--
-- Table structure for table `t_admin`
--

CREATE TABLE IF NOT EXISTS `t_admin` (
  `ad_id` varchar(10) NOT NULL,
  `ad_name` varchar(50) NOT NULL,
  `ad_pswd` varchar(50) NOT NULL,
  `ad_eml` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_admin`
--

INSERT INTO `t_admin` (`ad_id`, `ad_name`, `ad_pswd`, `ad_eml`) VALUES
('AD00000001', 'admin', 'admin', 'admin@gmail.com'),
('AD00002', 'Dilraj', 'QCoxFrwx', 'dilrajkaur18@gmail.com'),
('AD00003', 'sanchit', 'ejaaTgvN', 'sanchit.muz@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `t_status`
--

CREATE TABLE IF NOT EXISTS `t_status` (
  `s_id` varchar(50) NOT NULL,
  `s_stat` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_status`
--

INSERT INTO `t_status` (`s_id`, `s_stat`) VALUES
('AADHAR00006', 'Applied'),
('AADHAR00007', 'Applied'),
('AADHAR00008', 'Applied'),
('AADHAR00009', 'Applied'),
('AADHAR00010', 'Applied'),
('AADHAR00011', 'Applied'),
('AADHAR00012', 'Applied'),
('AADHAR00013', 'Applied'),
('AADHAR00014', 'Applied'),
('AADHAR00002', 'Applied'),
('AADHAR00015', 'Applied'),
('AADHAR00017', 'Applied'),
('AADHAR00018', 'Applied'),
('AADHAR00019', 'Applied'),
('AADHAR00020', 'Applied'),
('AADHAR00021', 'Applied'),
('AADHAR00022', 'Applied'),
('AADHAR00026', 'Applied');

-- --------------------------------------------------------

--
-- Table structure for table `t_user`
--

CREATE TABLE IF NOT EXISTS `t_user` (
  `s_detid` varchar(15) NOT NULL,
  `s_id` varchar(15) NOT NULL,
  `s_phn1` int(10) NOT NULL,
  `s_phn2` int(10) NOT NULL,
  `f_name` varchar(45) NOT NULL,
  `f_occ` varchar(45) NOT NULL,
  `f_phn` int(10) NOT NULL,
  `m_name` varchar(45) NOT NULL,
  `m_occ` varchar(45) NOT NULL,
  `m_phn` int(10) NOT NULL,
  `s_iop` text NOT NULL,
  `s_sex` varchar(6) NOT NULL,
  `s_cadr` varchar(50) NOT NULL,
  `s_cst` varchar(20) NOT NULL,
  `s_cpin` int(6) NOT NULL,
  `s_cmob` int(10) NOT NULL,
  `s_padr` varchar(50) NOT NULL,
  `s_pst` varchar(20) NOT NULL,
  `s_ppin` int(6) NOT NULL,
  `s_pmob` int(10) NOT NULL,
  `s_ruc` varchar(10) NOT NULL,
  `s_natn` varchar(10) NOT NULL,
  `s_relg` varchar(10) DEFAULT NULL,
  `s_catg` varchar(3) NOT NULL,
  `s_mainsxam` varchar(20) NOT NULL,
  `s_mainsrank` varchar(10) NOT NULL,
  `s_mainsroll` varchar(100) NOT NULL,
  `s_mainsbrnch` varchar(45) NOT NULL,
  `s_branch` varchar(60) NOT NULL,
  `s_college` varchar(20) NOT NULL,
  `s_center` varchar(20) NOT NULL,
  `s_crtype` varchar(200) NOT NULL,
  `s_pcm` varchar(10) NOT NULL,
  `s_tenbrd` varchar(7) NOT NULL,
  `s_tenyop` varchar(4) NOT NULL,
  `s_tentotmark` varchar(4) NOT NULL,
  `s_tenmarkob` varchar(4) NOT NULL,
  `s_tendiv` varchar(4) NOT NULL,
  `s_tenprcmark` varchar(4) NOT NULL,
  `s_twlbrd` varchar(7) NOT NULL,
  `s_twlyop` varchar(4) NOT NULL,
  `s_twltotmark` varchar(4) NOT NULL,
  `s_twlmarkob` varchar(4) NOT NULL,
  `s_twldiv` varchar(4) NOT NULL,
  `s_twlprcmark` varchar(4) NOT NULL,
  `s_moi` varchar(8) NOT NULL,
  `s_pay` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_user`
--

INSERT INTO `t_user` (`s_detid`, `s_id`, `s_phn1`, `s_phn2`, `f_name`, `f_occ`, `f_phn`, `m_name`, `m_occ`, `m_phn`, `s_iop`, `s_sex`, `s_cadr`, `s_cst`, `s_cpin`, `s_cmob`, `s_padr`, `s_pst`, `s_ppin`, `s_pmob`, `s_ruc`, `s_natn`, `s_relg`, `s_catg`, `s_mainsxam`, `s_mainsrank`, `s_mainsroll`, `s_mainsbrnch`, `s_branch`, `s_college`, `s_center`, `s_crtype`, `s_pcm`, `s_tenbrd`, `s_tenyop`, `s_tentotmark`, `s_tenmarkob`, `s_tendiv`, `s_tenprcmark`, `s_twlbrd`, `s_twlyop`, `s_twltotmark`, `s_twlmarkob`, `s_twldiv`, `s_twlprcmark`, `s_moi`, `s_pay`) VALUES
('DE00000002', 'AADHAR00007', 0, 0, 'SHAKTI KUMAR', 'BUSINESS', 0, 'SUMITRA KUMRI', 'HOUSE WIFE', 0, '1000', 'Male', 'SHANI BANGLOW, ROAD NO.3 EAST BORIWALI MUMBAI', 'MAHARASTRA', 410214, 0, 'SHANI BANGLOW, ROAD NO.3 EAST BORIWALI MUMBAI', 'MAHARASTRA', 410214, 0, 'Urban', 'INDIAN', 'HINDU', 'GEN', '--------------------', '0', '0', '0', '--------------------Select--------------------', '------', '--------------------', '----------', '0', 'STATE B', '1990', '500', '404', '1', '80.8', 'STATE B', '1992', '500', '222', '1', '80.8', 'Hindi', '2020/05/12'),
('DE00000003', 'AADHAR00008', 0, 0, 'DASRATH PATEL', 'BUSINESS', 0, 'KUNITA DEVI', 'HOUSE WIFE', 0, '1000', 'Female', 'MALIGHAT CHOWK, CHUNAA BHATI ROAD GALI NO.3', 'BIHAR', 842002, 2147483647, 'MALIGHAT CHOWK, CHUNAA BHATI ROAD GALI NO.3', 'BIHAR', 842002, 2147483647, 'Urban', 'INDIAN', 'HINDU', 'OBC', '--------------------', '0', '0', '0', '--------------------Select--------------------', '------', '--------------------', '----------', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'Hindi', 'Self'),
('DE00000004', 'AADHAR00009', 0, 0, 'GURUPREET SINGH', 'BUSINESS', 0, 'KULDEVI SINGH', 'HOUSE WIFE', 0, '10000', 'Female', 'FLA NO.99, NH99 RAURKELA ODISHA', 'ODISHA', 963205, 0, 'FLA NO.99, NH99 RAURKELA ODISHA', 'ODISHA', 963205, 0, 'Urban', 'INDIAN', 'HINDU', 'GEN', '--------------------', '0', '0', '0', '--------------------Select--------------------', '------', '--------------------', '----------', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'English', 'Self'),
('DE00000005', 'AADHAR00010', 0, 0, 'KIRAN YADAV', 'BUSINESS', 0, 'CHITA DEVI', 'HOUSE WIFE', 0, '1500000', 'Male', 'NALANDA HOUSE GALI NO.2 BHAGALPUR', 'BIHAR', 842450, 0, 'NALANDA HOUSE GALI NO.2 BHAGALPUR', 'BIHAR', 842450, 0, 'Urban', 'INDIAN', 'HINDU', 'OBC', '--------------------', '0', '0', '0', '--------------------Select--------------------', '------', '--------------------', '----------', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'Hindi', 'Self'),
('DE00000006', 'AADHAR00011', 0, 0, 'SURESH KUMAR ROY', 'BUSINESS', 0, 'RAKHI SINGH', 'HOUSE WIFE', 0, '100', 'Male', 'NEW TOWN HALL, NEAR BIG BAZA, SAHODARPUR', 'NEW DELHI', 110110, 0, 'NEW TOWN HALL, NEAR BIG BAZA, SAHODARPUR', 'NEW DELHI', 110101, 0, 'Urban', 'INDIAN', 'HINDU', 'OBC', '--------------------', '0', '0', '0', '--------------------Select--------------------', '------', '--------------------', '----------', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'English', 'Self'),
('DE00000007', 'AADHAR00012', 0, 0, 'KARAN KUMAR', 'BUSINESS', 0, 'KUMARI SHIVNAI', 'TEACHER', 0, '1000000', 'Male', 'INDIA', 'INDIA', 414141, 0, 'INDIA', 'INDIA', 414141, 0, 'Urban', 'India', 'Kumar', 'GEN', '--------------------', '222', '0', 'sd', '--------------------Select--------------------', '------', '--------------------', '----------', '22', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'English', 'Self'),
('DE00000008', 'AADHAR00013', 0, 0, 'SUNIL KUMAR OJHAA', 'DOCTOR', 0, 'SINITA SHARMA', 'HOUSE WIFE', 0, '156000', '', 'CHUNA BHATI TOAD NARIYALAPNI PATNA', 'BIHAR', 810010, 0, 'CHUNA BHATI TOAD NARIYALAPNI PATNA', 'BIHAR', 810010, 0, '', 'INDIAN', 'HINDU', '', 'No', '0', 'A MOLE ON NOSE', 'A MOLE ON DICK', 'Student', 'Not ap', 'Graduate', 'Electricit', '', '', '', '', '', '', '', '      ', '', '', '', '', '', '', ''),
('DE00000009', 'AADHAR00014', 2147483647, 250253699, 'BABA KAM DEV', 'BUSINESS', 0, 'SUJATA ', 'HOUSE WIFE', 0, '100', 'Male', 'HARIDAURNAGR ', 'UTTAR PRADESH', 624141, 2147483647, 'HARIDAUTNAGAR', 'UTTAR PRADESH', 625252, 1452369555, 'Rural', 'INDIAN', 'HINDU', 'GEN', 'No', '0', 'CUT ON FACE', 'LEFT LEG TILTTED', 'Agricultrual sector', 'above ', '8th', 'Passport', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
('DE00000010', 'AADHAR00002', 0, 0, 'SURESH KUMAR ROY', 'BUSINESS', 0, 'VEENA DEVI', 'HOUSE WIFE', 0, '100', 'Male', 'JUBBADAHNAI PARK NEAR GOLANAR MUZAFFARPUR UP', 'UP', 414121, 0, 'JUBBADAHNAI PARK NEAR GOLANAR MUZAFFARPUR UP', 'UP', 414141, 0, 'Rural', 'INDIAN', 'HINDU', 'GEN', 'No', '0', 'A MOLE ON NOSE', 'A MOLE ON DICK', 'Student', 'Not ap', 'Graduate', 'Certificat', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
('DE00000011', 'AADHAR00015', 0, 0, 'SAHKTI KAPOOR', 'AGRICULTURE', 0, 'REENA DEVI', 'HOUSE WIFE', 0, '10000', 'Male', 'HOUSE NO 191 NAVI MUMBAI', 'MAHARASTRA ', 410011, 0, 'MUMBAI', 'MAHARASTRA', 410011, 0, 'Urban', 'INDIAN', 'HINDU', 'GEN', 'No', '0', 'A MOLE ON NOSE', 'A MOLE ON DICK', 'Student', 'Not ap', 'Graduate', 'Bank State', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
('DE00000012', 'AADHAR00017', 0, 0, 'MANOJ KUMAR SINGH', 'TEACHER', 0, 'SUCHITEA DEVI', 'HOUSE WIFE', 0, '100000', 'Female', 'BAJOPATTI GALI NO 06 SITAMAHRI', 'BIHAR', 842006, 0, 'BAJOPATTI GALI NO 06 SITAMAHRI', 'BIHAR', 842006, 0, 'Rural', 'INDIAN', 'HINDU', 'GEN', 'No', '0', 'A CUTE EYE', 'A CUTE FACE', 'Student', 'Not ap', 'Graduate', 'Certificat', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
('DE00000013', 'AADHAR00018', 0, 0, 'SUNIL KUMAR', 'EX-MAN', 0, 'RETA DEVI', 'HOUSE WIFE', 0, '10', 'Male', 'HARISHANKAR MANIYARI SILOUT MUZAFFARPUR', 'BIHAR', 842001, 140140144, 'HARISHANKAR MANIYARI SILOUT MUZAFFARPUR', 'BIHAR', 842001, 140140144, 'Urban', 'INDIAN', 'HINDU', 'GEN', 'No', '0', 'CUT ON FACE', 'EYE BRO CUT', 'Student', 'Not applicable', 'Graduate', 'Government Photo ID Cards/ service photo identity card', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2020/06/17'),
('DE00000014', 'AADHAR00019', 0, 0, 'SUMIT JAYAKAR', 'BUSINESS', 0, 'SUNITA JAYAKAAR', 'CORPORATE', 0, '100000', 'Male', 'NAVI MUMBAI GALI NO 06 MUMBAI', 'MAHARASTRA', 400001, 0, 'NAVI MUMBAI GALI NO 06 MUMBAI', 'MAHARASTRA', 400001, 2147483647, 'City', 'INDIAN', 'HINDU', 'GEN', 'No', '0', 'CURLEY HAIR', 'CUT ON RIGHT HAND', 'Self employed', 'below 150000', 'Graduate', 'Photo ID issued by Recognized Educational Institution', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2020/04/22'),
('DE00000015', 'AADHAR00020', 0, 0, 'demo', 'demo', 0, 'demo', 'demo', 0, '000000', 'Male', 'demo', 'demo', 0, 0, 'demo', 'demo', 0, 0, 'Rural', 'INDIAN', 'DEMO', 'GEN', 'No', '0', 'NIL', 'NIL', 'Center Gov. Employ', 'above 150000', 'Graduate', 'Photo ID issued by Recognized Educational Institution', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2019/05/18'),
('DE00000016', 'AADHAR00021', 0, 0, 'ARUN KUMAR SINGH', 'INDIAN RAILWAYS', 0, 'RENU VERMA', 'HOUSE WIFE', 0, '1000000', 'Male', 'RK PURAM ROAD NEAR AMARPALI MALL MUZAFFARPUR', 'BIHAR', 842002, 2147483647, 'RK PURAM ROAD NEAR AMARPALI MALL MUZAFFARPUR', 'BIHAR', 842002, 2147483647, 'City', 'INDIAN', 'HINDU', 'GEN', 'No', '0', 'A MOLE ON FACE', 'A MOLE ON NECK', 'Student', 'Not applicable', 'Graduate', 'Ration/ PDS Photo Card', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2022/01/01'),
('DE00000017', 'AADHAR00022', 0, 0, 'SURENDAR PATEL', 'BUSINESS', 0, 'KACHI KALI', 'HOUSE WIFE', 0, '100000', 'Male', 'MALIGHAT CHOWK, CHUNAA BHATI ROAD GALI NO.3', 'UTTAR PRADESH', 400001, 2147483647, 'MALIGHAT CHOWK, CHUNAA BHATI ROAD GALI NO.3', 'UTTAR PRADESH', 400001, 2147483647, 'Urban', 'INDIAN', 'HINDU', 'GEN', 'No', '0', 'A MOLE ON CHECK', 'A MOLE ON RIGHT HAND', 'Business', 'above 150000', 'Post Graduate', 'Voter ID', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2022/01/01'),
('DE00000018', 'AADHAR00026', 0, 0, 'RAHUL KHOLI', 'BUSINESS', 0, 'SUJATAA DEVI', 'HOUSE WIFE', 0, '10000', 'Male', 'R K PURAM NEAR METRO STATION NEW DELHI', 'NEW DELHI', 100001, 2147483647, 'R K PURAM NEAR METRO STATION NEW DELHI', 'NEW DELHI', 100001, 2147483647, 'Urban', 'INDIAN', 'HINDU', 'GEN', 'No', '0', 'A MOLE ON FACE', 'A MOLE ON RIGHT HAND', 'Center Gov. Employ', 'above 150000', 'Graduate', 'Voter ID', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2022/01/01');

-- --------------------------------------------------------

--
-- Table structure for table `t_userdoc`
--

CREATE TABLE IF NOT EXISTS `t_userdoc` (
  `s_id` varchar(15) NOT NULL,
  `s_pic` varchar(200) NOT NULL,
  `s_tenmarkpic` varchar(200) NOT NULL,
  `s_tencerpic` varchar(200) NOT NULL,
  `s_twdmarkpic` varchar(200) NOT NULL,
  `s_twdcerpic` varchar(200) NOT NULL,
  `s_idprfpic` varchar(200) NOT NULL,
  `s_sigpic` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_userdoc`
--

INSERT INTO `t_userdoc` (`s_id`, `s_pic`, `s_tenmarkpic`, `s_tencerpic`, `s_twdmarkpic`, `s_twdcerpic`, `s_idprfpic`, `s_sigpic`) VALUES
('AADHAR00006', '305943-Shahrukhphotofile-1323752410-576-640x480.jpg', 'images.jpg', 'images (1).jpg', 'images.jpg', 'AADHAAR-Card-Application-Form.jpg', 'images (3).jpg', 'images (2).jpg'),
('AADHAR00007', '305943-Shahrukhphotofile-1323752410-576-640x480.jpg', 'images.jpg', 'images (1).jpg', 'images.jpg', 'AADHAAR-Card-Application-Form.jpg', 'images (3).jpg', 'images (2).jpg'),
('AADHAR00008', 'download.jpg', 'images.jpg', 'images (1).jpg', 'images.jpg', 'AADHAAR-Card-Application-Form.jpg', 'images (3).jpg', 'images (2).jpg'),
('AADHAR00009', 'download.jpg', '111.png', '222.png', '222.png', '222.png', '222.png', 'download.jpg'),
('AADHAR00010', '111.png', '222.png', '222.png', '111.png', '222.png', '222.png', '111.png'),
('AADHAR00010', '222.png', '222.png', '111.png', '111.png', '222.png', '222.png', '111.png'),
('AADHAR00010', '111.png', '222.png', '222.png', '111.png', '222.png', '222.png', '111.png'),
('AADHAR00010', '222.png', '222.png', '111.png', '222.png', '222.png', '222.png', '111.png'),
('AADHAR00011', 'icg.jpg', 'THUMB.jpeg', '20181106_172754.jpg', 'THUMB.jpeg', 'aadhar.JPG', 'aadhar back DONE.JPG', '20181106_172754.jpg'),
('AADHAR00012', 'thequint_2018-01_3630b14c-7dce-4987-8325-748874b28c8c_adhar-UDAI.gif', '111.png', '222.png', '222.png', '222.png', '111.png', '222.png'),
('AADHAR00013', 'download.jpg', 'aadhar card.jpg', 'aadhar card.jpg', 'aadhar card.jpg', 'aadhar card.jpg', 'checklink.jpg', 'linkcheck.jpg'),
('AADHAR00014', 'Baba-Ramdev.jpg', 'aadhar card.jpg', 'aadhar card.jpg', 'aadhar card.jpg', 'aadhar card.jpg', 'Aadhar number.jpg', 'download (1).jpg'),
('AADHAR00002', 'link-aadhaar-pan.jpg', 'link-aadhaar-pan.jpg', 'link-aadhaar-pan.jpg', 'link-aadhaar-pan.jpg', 'link-aadhaar-pan.jpg', 'link-aadhaar-pan.jpg', 'link-aadhaar-pan.jpg'),
('AADHAR00015', 'download.jpg', '111.png', '222.png', '111.png', '222.png', '111.png', '111.png'),
('AADHAR00017', 'download (1).jpg', '111.png', '111.png', '111.png', '222.png', '222.png', '222.png'),
('AADHAR00018', 'amaan-shakoor.jpg', '111.png', '111.png', '222.png', '111.png', '111.png', '222.png'),
('AADHAR00019', 'download (2).jpg', '111.png', '111.png', '222.png', '222.png', '222.png', '111.png'),
('AADHAR00021', 'FACE.jpg', 'THUMBR.jpg', 'RETINA.jpg', 'THUMBL.jpg', 'APP.jpg', 'RATION CARD.jpg', 'SIG.jpg'),
('AADHAR00022', 'download.jpg', 'THUMBR.jpg', 'RETINA.jpg', 'THUMBL.jpg', 'APP.jpg', 'RATION CARD.jpg', 'SIG.jpg'),
('AADHAR00026', 'vurat.jpg', 'THUMBL.jpg', 'RETINA.jpg', 'THUMBR.jpg', 'APP.jpg', 'RATION CARD.jpg', 'SIG.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `t_usermark`
--

CREATE TABLE IF NOT EXISTS `t_usermark` (
  `s_id` varchar(50) NOT NULL,
  `s_omr` varchar(50) NOT NULL,
  `s_mark` int(5) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `t_user_data`
--

CREATE TABLE IF NOT EXISTS `t_user_data` (
  `s_id` varchar(15) NOT NULL,
  `s_pwd` varchar(15) NOT NULL,
  `s_dob` date DEFAULT NULL,
  `s_name` varchar(45) NOT NULL,
  `fname` text NOT NULL,
  `s_email` varchar(45) NOT NULL,
  `s_mob` varchar(10) DEFAULT NULL,
  `ad1` text NOT NULL,
  `ad2` text NOT NULL,
  `dis` text NOT NULL,
  `state` text NOT NULL,
  `pin` text NOT NULL,
  `used` text NOT NULL,
  `s_signupdate` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_user_data`
--

INSERT INTO `t_user_data` (`s_id`, `s_pwd`, `s_dob`, `s_name`, `fname`, `s_email`, `s_mob`, `ad1`, `ad2`, `dis`, `state`, `pin`, `used`, `s_signupdate`) VALUES
('AADHAR00001', 'airpot', '0000-00-00', 'Airport Authority of India', '', 'sajkjkj@gmail.com', '7458963215', '', '', '', '', '', '', '2019-05-09 00:00:00.000000'),
('AADHAR00002', 'JmyTQSeG', '1997-01-01', 'Sanchit Kumar', 'SURESH KUMAR ROY', 'sanchit.muz@gmail.com', '9879521000', 'JUBBASHANI PARK', 'NEAR GOLAMBAR', 'MUZAFFARPUR', 'UTTAR PRADESH', '412355', '', '2019-05-03 01:55:39.000000'),
('AADHAR00003', 'AGp7lSFc', '2004-05-05', 'RANJIT KUMAR', '', 'RANJIT@GMAIL.COM', '7412589632', '', '', '', '', '', '', '2019-05-03 01:59:03.000000'),
('AADHAR00004', 'Hx0hUDyU', '2019-04-17', 'KISHLAY RANJAN', '', 'KISHLAY@GMAIL.COM', '7897897890', '', '', '', '', '', '', '2019-05-03 13:29:05.000000'),
('AADHAR00005', 'RnsrFH0X', '2019-04-10', 'SANCHIT KUMAR', '', 'RIK@GMAIL.COM', '1236547890', '', '', '', '', '', '', '2019-05-03 13:30:14.000000'),
('AADHAR00006', 'MnwSmJHd', '2019-04-17', '', '', 'SAHYUK@GMAIL.COM', '7148529630', '', '', '', '', '', '', '2019-05-03 13:39:42.000000'),
('AADHAR00007', 'YWRE7SW9', '2019-04-17', 'KUMAR SHANI', 'SHAKTI KUMAR', 'KUMAR@SHANI.COM', '0000000000', 'SHANI BANGALOW ROAD NO.3', 'BORIWALI EAST', 'MUMBAI', 'MAHARASTRA', '410214', '', '2019-05-04 10:10:45.000000'),
('AADHAR00008', '5JZXmZdN', '2019-04-17', 'GUNJA DEVI', 'MUKESH PATEL', 'mukesh@gmail.com', '7412589630', 'MALIGHAT CHOWK', 'CHUNA BHATI ROAD GALI NO.3', 'MUZAFFARPUR', 'BIHAR', '842002', '', '2019-05-04 17:21:37.000000'),
('AADHAR00009', 'uhhVxc7G', '2019-04-10', 'SHENA SINGH', 'GURUPREET SINGH', 'SHEN@EMAIL.IN', '0000000000', 'FLAT NO. 225, N99 ROAD', 'RAUKELA', 'RUUKELA', 'ODISHA', '963255', '', '2019-05-06 23:25:22.000000'),
('AADHAR00010', 'IozZgCcQ', '1994-04-01', 'SURYA KUMAR YADAV', 'KIRAN YADAV', 'SURY@NIC.IN', '0002325145', 'NALANDA HOUSE', 'GALI NO.2', 'BAHGALPUR', 'BIHAR', '842155', '', '2019-05-08 12:50:02.000000'),
('AADHAR00011', 'G4D4FFs3', '2019-04-10', 'SANCHIT KUMAR', 'SURESH KUMAR ROY', 'demohaiyemeail@demimail.ni', '8789250000', 'NEW TOWN HALL', 'NEAR BIG BAZAR', 'KHOLSHOLAPUR', 'NEW DELHI', '110101', '', '2019-05-09 06:23:53.000000'),
('AADHAR00012', '54K8pB6U', '2019-04-10', 'RAGHAV SINGH', 'KAMALJEET SINGH', 'DUM@DUM.COM', '0000000000', 'INDIA', 'INDIA', 'INDIA', 'MUMBAI', '414141', '1', '2019-05-09 09:31:02.000000'),
('AADHAR00013', 'XLADtnJt', '2019-04-10', 'KISHLAY RANJAN', 'SUNIL KUMAR OJHA', 'KISHLAY@BA.COM', '0000000000', 'CHUNA BAHTI ROAD', 'NARILYAPANI SECTOR', 'PATNA', 'BIHAR', '800010', '', '2019-05-10 12:04:49.000000'),
('AADHAR00014', '5nwSKrtH', '2019-04-17', 'BABA RAM DEV', 'MAHARISHI PATANJALI', 'RAMDEV@NIC.IN', '1452369878', 'HARIDAUR NAGAR', 'CHIRAUND ROAD', 'HARIDAUR', 'UATTAR PRADESH', '625141', '', '2019-05-11 03:24:38.000000'),
('AADHAR00015', 'MhngKgAb', '2019-04-10', 'RAVAN SINGH', 'SHRI GUPTPA SINGH', 'JHSJSJHASJ@GMAIL.COM', '000000000', 'HOUSE NO 141 NEW TOWN ROAD', 'NAVI MUMBAI', 'MUMBAI', 'MAHARASTRA', '401101', '', '2019-05-13 21:45:58.000000'),
('AADHAR00016', 'xabyPcc3', '2019-04-04', 'ANMOL SINGH', 'MANIJ KUMAR SINGH', 'ASHJSAJSJ@GAh.com', '000000000', 'chatta chowk', 'muzaffarprur', 'muzaffarpur', 'bihar', '845555', '', '2019-05-13 21:49:45.000000'),
('AADHAR00017', '4XI5cWHh', '2019-04-04', 'SHIVANI SINGH', 'MANOJ KUMAR SINGH', 'SHIB@NICC.IN', '000000000', 'BAJOPATTI', 'GALI NO 06', 'SITAMAHRI', 'BIHAR', '842006', '', '2019-05-15 07:53:29.000000'),
('AADHAR00018', '2rAFUaVJ', '1994-10-10', 'SHUBHAM KUMAR', 'SUNIL KUMAR', 'SHUBHAM@NIC.ICO.IN', '0147101111', 'HARISHANKAR MANIYARI', 'SILOUT', 'MUZAFFARPUR', 'BIHAR', '842001', '', '2019-05-17 07:36:55.000000'),
('AADHAR00019', 'aPGPdHYL', '2019-04-10', 'RAHUL JAYAKAR', 'SMIT JAYAKAR', 'JAYKAR@JAYKAR.IN', '0000000000', 'NAVI MUMUBAI', 'GALI NO 06', 'MUMBAI', 'MAHARASTRA', '400001', '', '2019-05-18 09:14:34.000000'),
('AADHAR00020', 'AqTVI6C8', '2019-04-10', 'DEMO', 'DEMO', 'TEST@TEST.COM', '0000000000', 'DEMO', 'DEMO', 'DEMO', 'DEMO', '000000', '', '2019-05-18 10:25:51.000000'),
('AADHAR00021', 'o8XMcVHS', '1995-11-02', 'ANKIT ANAND', 'ARUN KUMAR VERMA', 'ANKIT71277400@GMAIL.COM', '9174145474', 'RK PURAM ROAD', 'NEAR AMARPALI MALL', 'MUZAFFARPUR', 'BIHAR', '842002', '', '2019-05-25 22:02:21.000000'),
('AADHAR00022', '7jyQ7Qe1', '1994-04-05', 'JITENDAR PATEL', 'SURENDAR PATEL', 'JITENDAR.PATEL@GMAIL.COM', '9147852369', 'MALIGHAT CHOWK', 'CHUNA BHATTI ROAD GALI NO 03', 'MUZAFFARNAGAR', 'UATTAR PRADESH', '400001', '1', '2019-05-28 02:05:33.000000'),
('AADHAR00023', 'qsBmPJRA', '1994-01-02', 'GAURAV KUMAR', 'MANOJ DUBEY', 'GAURAVINDIA@GMAIL.COM', '9147852369', 'GAURAV NARSHING HOME', 'GANNIPUR', 'MUZAFFARNAGAR', 'UATTAR PRADESH', '400001', '', '0000-00-00 00:00:00.000000'),
('AADHAR00024', 'FNdP0tCE', '2019-04-25', 'Sanchit Kumar', 'Sanchit', 'aSAaeaw@esds.vhh', '11111', '1ssaA', 'aAa', 'ASaA', 'BiharASA', '842001SAS', '', '2019-05-28 02:16:41.000000'),
('AADHAR00025', 'X6rx38OU', '2019-04-04', 'Sanchit Kumar', 'Sanchit', 'aASASAaa#j@gmail.com', '65656536', 'HOMELESS CHOWK ,KHABRA ROAD', 'saasas', 'asas', 'Biharasas', '2212121', '0', '2019-05-28 02:27:25.000000'),
('AADHAR00026', 'diGUs57n', '1994-04-01', 'VIRAT KHOLI', 'RAHUL KHOLI', 'VIRAT@VIRAT.COM', '9147852369', 'R.K PURAM', 'NEAR METRO STATION', 'DELHI', 'NEW DELHI', '100001', '1', '2019-05-29 02:30:28.000000');

-- --------------------------------------------------------

--
-- Table structure for table `visitor_info`
--

CREATE TABLE IF NOT EXISTS `visitor_info` (
`id` int(11) NOT NULL,
  `ip_address` varchar(255) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `time_accessed` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=207 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `visitor_info`
--

INSERT INTO `visitor_info` (`id`, `ip_address`, `user_agent`, `time_accessed`) VALUES
(1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 16:26:52'),
(2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 16:27:01'),
(3, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 16:27:40'),
(4, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 16:27:55'),
(5, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 16:28:01'),
(6, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 16:28:12'),
(7, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 16:28:19'),
(8, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 16:28:22'),
(9, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 16:28:29'),
(10, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 16:28:32'),
(11, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 16:28:35'),
(12, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 16:28:38'),
(13, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 16:29:05'),
(14, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 16:29:09'),
(15, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 16:29:18'),
(16, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 16:29:25'),
(17, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 16:29:28'),
(18, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 16:29:51'),
(19, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 16:29:57'),
(20, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 16:30:00'),
(21, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 16:30:07'),
(22, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 16:30:15'),
(23, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 16:39:41'),
(24, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 16:40:41'),
(25, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 16:41:27'),
(26, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 17:26:10'),
(27, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 17:27:34'),
(28, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 17:28:20'),
(29, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 17:28:42'),
(30, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 17:30:26'),
(31, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 17:30:38'),
(32, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 17:30:41'),
(33, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 17:30:43'),
(34, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 17:30:45'),
(35, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 17:30:48'),
(36, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 17:30:51'),
(37, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 17:30:53'),
(38, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 17:30:56'),
(39, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 17:30:59'),
(40, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 17:32:02'),
(41, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 17:32:05'),
(42, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 17:32:07'),
(43, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 17:32:10'),
(44, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 19:08:04'),
(45, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 19:08:14'),
(46, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 21:43:06'),
(47, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 21:47:01'),
(48, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 21:47:08'),
(49, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 21:48:58'),
(50, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 21:49:18'),
(51, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27 22:22:28'),
(52, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-28 01:41:41'),
(53, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-28 01:43:58'),
(54, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-28 01:46:23'),
(55, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-03 20:25:28'),
(56, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-03 20:26:21'),
(57, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-03 20:26:43'),
(58, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-03 20:27:12'),
(59, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-03 20:27:51'),
(60, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-03 20:28:29'),
(61, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-03 20:33:54'),
(62, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-03 20:38:39'),
(63, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-03 20:44:04'),
(64, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-04 03:01:18'),
(65, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-04 03:03:46'),
(66, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-04 03:12:18'),
(67, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-04 03:14:06'),
(68, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-04 16:07:23'),
(69, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-04 16:07:40'),
(70, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-04 16:08:09'),
(71, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-04 17:02:30'),
(72, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-05 00:19:02'),
(73, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-05 00:19:30'),
(74, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-05 01:43:19'),
(75, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-05 16:35:12'),
(76, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-05 16:36:51'),
(77, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-05 16:37:54'),
(78, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-05 16:38:12'),
(79, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-05 16:38:27'),
(80, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-05 16:44:47'),
(81, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-05 17:04:10'),
(82, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-05 17:04:22'),
(83, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-05 17:05:38'),
(84, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-06 00:57:22'),
(85, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-06 00:58:33'),
(86, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-06 01:01:04'),
(87, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-06 01:03:35'),
(88, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-06 21:18:00'),
(89, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-06 21:18:34'),
(90, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-06 21:20:32'),
(91, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-06 21:25:37'),
(92, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-06 21:27:11'),
(93, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-06 21:27:31'),
(94, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-06 21:27:41'),
(95, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-06 21:28:03'),
(96, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-07 04:36:41'),
(97, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-07 04:59:08'),
(98, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-07 04:59:14'),
(99, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-07 05:04:48'),
(100, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-07 06:17:11'),
(101, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-07 06:22:20'),
(102, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-07 06:23:16'),
(103, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-07 06:25:32'),
(104, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-07 06:29:39'),
(105, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-07 06:30:17'),
(106, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-07 06:39:50'),
(107, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-07 06:43:02'),
(108, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-07 07:06:49'),
(109, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-07 07:09:48'),
(110, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-07 17:39:53'),
(111, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-07 17:40:00'),
(112, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-07 18:12:16'),
(113, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-07 18:30:03'),
(114, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-07 18:30:34'),
(115, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-07 18:33:10'),
(116, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-07 18:33:56'),
(117, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-08 15:10:02'),
(118, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-08 15:35:59'),
(119, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-08 15:38:19'),
(120, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-08 15:40:59'),
(121, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-08 15:42:46'),
(122, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '2019-05-08 15:54:35'),
(123, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-08 19:35:50'),
(124, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-08 19:39:30'),
(125, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-08 19:41:46'),
(126, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-08 19:42:14'),
(127, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-08 19:44:32'),
(128, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-08 19:49:09'),
(129, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-08 19:50:24'),
(130, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-08 19:53:22'),
(131, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-08 20:01:52'),
(132, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-09 13:11:51'),
(133, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-09 13:16:27'),
(134, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-09 13:22:16'),
(135, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-09 13:24:09'),
(136, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-09 13:24:22'),
(137, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-09 13:36:22'),
(138, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-09 13:37:19'),
(139, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-09 13:53:16'),
(140, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-09 13:55:16'),
(141, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-09 13:55:38'),
(142, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-09 13:56:41'),
(143, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-09 13:58:00'),
(144, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-09 15:58:45'),
(145, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-09 16:12:01'),
(146, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-09 16:13:41'),
(147, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-09 16:24:55'),
(148, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-09 16:27:40'),
(149, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-09 16:28:45'),
(150, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-09 16:30:00'),
(151, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-09 16:31:13'),
(152, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-09 16:32:05'),
(153, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-09 16:33:22'),
(154, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-09 16:39:43'),
(155, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-09 16:43:42'),
(156, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-09 16:44:09'),
(157, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-09 18:36:53'),
(158, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-09 18:38:52'),
(159, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-09 18:39:22'),
(160, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-09 18:39:57'),
(161, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-09 18:42:59'),
(162, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-09 18:44:05'),
(163, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-09 18:54:15'),
(164, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-09 19:03:16'),
(165, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-10 18:29:49'),
(166, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-10 18:57:41'),
(167, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-10 19:03:13'),
(168, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-10 19:05:02'),
(169, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-10 19:05:06'),
(170, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-10 19:05:32'),
(171, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-10 19:10:03'),
(172, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-10 19:10:34'),
(173, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-10 19:41:02'),
(174, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-10 19:41:39'),
(175, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-10 19:44:11'),
(176, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-10 19:45:02'),
(177, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-11 02:52:17'),
(178, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-11 10:10:30'),
(179, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-11 10:11:30'),
(180, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-11 10:23:39'),
(181, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-11 10:24:44'),
(182, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-11 10:31:10'),
(183, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-11 10:33:50'),
(184, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-11 10:34:45'),
(185, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-12 05:16:17'),
(186, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-12 05:34:18'),
(187, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-12 11:37:44'),
(188, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-12 11:46:46'),
(189, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-12 17:24:34'),
(190, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-12 18:27:19'),
(191, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-13 04:37:39'),
(192, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-13 05:08:21'),
(193, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-13 09:44:20'),
(194, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-13 09:45:08'),
(195, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-13 09:45:46'),
(196, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-13 09:50:21'),
(197, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-13 09:52:51'),
(198, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-13 09:56:38'),
(199, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-13 10:00:42'),
(200, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-13 10:11:23'),
(201, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-14 04:19:00'),
(202, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-14 04:19:40'),
(203, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-14 04:21:23'),
(204, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-14 04:24:20'),
(205, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-14 04:28:41'),
(206, '::1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', '2019-05-14 04:34:41');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aai`
--
ALTER TABLE `aai`
 ADD PRIMARY KEY (`member_id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `banner_posts`
--
ALTER TABLE `banner_posts`
 ADD PRIMARY KEY (`id`), ADD KEY `title` (`title`);

--
-- Indexes for table `blogs`
--
ALTER TABLE `blogs`
 ADD PRIMARY KEY (`id`), ADD KEY `category` (`category`);

--
-- Indexes for table `blog_categories`
--
ALTER TABLE `blog_categories`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
 ADD PRIMARY KEY (`contact_id`);

--
-- Indexes for table `editors_choice`
--
ALTER TABLE `editors_choice`
 ADD PRIMARY KEY (`id`), ADD KEY `blog` (`blog`);

--
-- Indexes for table `links`
--
ALTER TABLE `links`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `locals`
--
ALTER TABLE `locals`
 ADD PRIMARY KEY (`local_id`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `membership_grouppermissions`
--
ALTER TABLE `membership_grouppermissions`
 ADD PRIMARY KEY (`permissionID`);

--
-- Indexes for table `membership_groups`
--
ALTER TABLE `membership_groups`
 ADD PRIMARY KEY (`groupID`);

--
-- Indexes for table `membership_userpermissions`
--
ALTER TABLE `membership_userpermissions`
 ADD PRIMARY KEY (`permissionID`);

--
-- Indexes for table `membership_userrecords`
--
ALTER TABLE `membership_userrecords`
 ADD PRIMARY KEY (`recID`), ADD UNIQUE KEY `tableName_pkValue` (`tableName`,`pkValue`), ADD KEY `pkValue` (`pkValue`), ADD KEY `tableName` (`tableName`), ADD KEY `memberID` (`memberID`), ADD KEY `groupID` (`groupID`);

--
-- Indexes for table `membership_users`
--
ALTER TABLE `membership_users`
 ADD PRIMARY KEY (`memberID`), ADD KEY `groupID` (`groupID`);

--
-- Indexes for table `olevel`
--
ALTER TABLE `olevel`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `olevel_upload`
--
ALTER TABLE `olevel_upload`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `page_hits`
--
ALTER TABLE `page_hits`
 ADD PRIMARY KEY (`page`);

--
-- Indexes for table `paycheck`
--
ALTER TABLE `paycheck`
 ADD PRIMARY KEY (`member_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `programs`
--
ALTER TABLE `programs`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ref`
--
ALTER TABLE `ref`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `titles`
--
ALTER TABLE `titles`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_admin`
--
ALTER TABLE `t_admin`
 ADD PRIMARY KEY (`ad_id`);

--
-- Indexes for table `t_status`
--
ALTER TABLE `t_status`
 ADD KEY `s_id` (`s_id`);

--
-- Indexes for table `t_user`
--
ALTER TABLE `t_user`
 ADD PRIMARY KEY (`s_detid`), ADD KEY `s_id` (`s_id`);

--
-- Indexes for table `t_userdoc`
--
ALTER TABLE `t_userdoc`
 ADD KEY `s_id` (`s_id`);

--
-- Indexes for table `t_usermark`
--
ALTER TABLE `t_usermark`
 ADD KEY `s_id` (`s_id`);

--
-- Indexes for table `t_user_data`
--
ALTER TABLE `t_user_data`
 ADD PRIMARY KEY (`s_id`);

--
-- Indexes for table `visitor_info`
--
ALTER TABLE `visitor_info`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aai`
--
ALTER TABLE `aai`
MODIFY `member_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `banner_posts`
--
ALTER TABLE `banner_posts`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `blogs`
--
ALTER TABLE `blogs`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `blog_categories`
--
ALTER TABLE `blog_categories`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
MODIFY `contact_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `editors_choice`
--
ALTER TABLE `editors_choice`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `links`
--
ALTER TABLE `links`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `locals`
--
ALTER TABLE `locals`
MODIFY `local_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=738;
--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT for table `membership_grouppermissions`
--
ALTER TABLE `membership_grouppermissions`
MODIFY `permissionID` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=37;
--
-- AUTO_INCREMENT for table `membership_groups`
--
ALTER TABLE `membership_groups`
MODIFY `groupID` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `membership_userpermissions`
--
ALTER TABLE `membership_userpermissions`
MODIFY `permissionID` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `membership_userrecords`
--
ALTER TABLE `membership_userrecords`
MODIFY `recID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `olevel`
--
ALTER TABLE `olevel`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `olevel_upload`
--
ALTER TABLE `olevel_upload`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `paycheck`
--
ALTER TABLE `paycheck`
MODIFY `member_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=40;
--
-- AUTO_INCREMENT for table `programs`
--
ALTER TABLE `programs`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `ref`
--
ALTER TABLE `ref`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `titles`
--
ALTER TABLE `titles`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `visitor_info`
--
ALTER TABLE `visitor_info`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=207;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `t_status`
--
ALTER TABLE `t_status`
ADD CONSTRAINT `t_status_ibfk_1` FOREIGN KEY (`s_id`) REFERENCES `t_user_data` (`s_id`);

--
-- Constraints for table `t_user`
--
ALTER TABLE `t_user`
ADD CONSTRAINT `t_user_ibfk_1` FOREIGN KEY (`s_id`) REFERENCES `t_user_data` (`s_id`);

--
-- Constraints for table `t_userdoc`
--
ALTER TABLE `t_userdoc`
ADD CONSTRAINT `t_userdoc_ibfk_1` FOREIGN KEY (`s_id`) REFERENCES `t_user_data` (`s_id`);

--
-- Constraints for table `t_usermark`
--
ALTER TABLE `t_usermark`
ADD CONSTRAINT `t_usermark_ibfk_1` FOREIGN KEY (`s_id`) REFERENCES `t_user_data` (`s_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
