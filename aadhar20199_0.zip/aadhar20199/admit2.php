<?php

    session_start();
    error_reporting(0);

$con=mysqli_connect("localhost","root","","oas2");
$q=mysqli_query($con,"select s_name,s_dob,fname,ad1,ad2, dis, state, pin, s_mob from t_user_data where s_id='".$_SESSION['user']."'");
$n=  mysqli_fetch_assoc($q);
$stname= $n['s_name'];
$stdob= $n['s_dob'];
$fname= $n['fname'];
$ad1= $n['ad1'];
$ad2= $n['ad2'];
$dis= $n['dis'];
$state= $n['state'];
$pin= $n['pin'];
$smob= $n['s_mob'];


$id=$_SESSION['user'];

$result = mysqli_query($con,"SELECT * FROM t_user WHERE s_id='".$_SESSION['user']."'");
                    
                    while($row = mysqli_fetch_array($result))
                      {
?>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
        <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
         <link rel="stylesheet" href="bootstrap/bootstrap-theme.min.css">
       <script src="bootstrap/jquery.min.js"></script>
        <script src="bootstrap/bootstrap.min.js"></script>
        <link type="text/css" rel="stylesheet" href="css/admform.css"></link>
       
        
        <script type="text/javascript">
            function printpage()
            {
            var printButton = document.getElementById("print");
            printButton.style.visibility = 'hidden';
            window.print()
             printButton.style.visibility = 'visible';
             }
        </script>
</head>
    <body style="background-image:url(./images/inbg.jpg) ">
      <form id="adminac" action="adminac.php" method="post">
            
          <div class="container-fluid">
                            <div class="row">
                               <div class="col-sm-12">
      <center>  <table class="table table-bordered" style="font-family: Verdana">
                
                <tr>
                 <td style="width:3%;"><img src="./images/Logo-T.png" width="50%"> </td>
                 <td style="width:8%;"><center><font style="font-family:Arial Black; font-size:20px;">
                    Aadhar card letter</font></center>
                
                <center><font style="font-family:Verdana; font-size:18px;">
                   Government of India, under the Ministry of Electronics and Information Technology 
                    </font></center>
                
                <br>
                <br>
                <center><font style="font-family:Arial Black; font-size:20px;">
		Unique Identity of Authority of India
                   </font></center>
                </td>
                    <td colspan="2" width="3%" >
                        <?php
                  
                    $picfile_path ='studentpic/';
                    
                    $result1 = mysqli_query($con,"SELECT * FROM t_userdoc where s_id='".$_SESSION['user']."'");
             
                    while($row1 = mysqli_fetch_array($result1))
                      {                  
                        $picsrc=$picfile_path.$row1['s_pic'];
                        
                        echo "<img src='$picsrc.' class='img-thumbnail' width='180px' style='height:180px;'>";
                        echo"<div>";
                      }
                   ?>
                        </td>
               
                   </tr>       
                 
                 
                 <tr>
                 <td style="width:4%;"> <font style="font-family: Verdana;">Aadhar Number </font> </td>				
                    <td style="width:8%;" colspan="3"><font style="font-family: Verdana; font-weight: bold">
                     <?php echo $id;?></font> </td>
                 </tr>       
                 
                 
                 <tr>
                 <td style="width:4%;"> <font style="font-family: Verdana;">Name  </font> </td>
                    <td style="width:8%;" colspan="3"><font style="font-family: Verdana; font-weight: bold">
                     <?php echo $stname;?></font> </td>
                 </tr>

                 
                 <tr>
                 <td style="width:4%;"> <font style="font-family: Verdana;">Date of birth  </font> </td>
                    <td style="width:8%;" colspan="3"><font style="font-family: Verdana; font-weight: bold">
                     <?php echo $stdob;?></font> </td>
                 </tr>
<br><br>

 <center>  <table class="table table-bordered" style="font-family: Verdana">
                
                <tr>
                 <td style="width:3%;"><img src="./images/Logo-T.png" width="50%"> </td>
                 <td style="width:8%;"><center><font style="font-family:Arial Black; font-size:20px;">
                    Aadhar card letter</font></center>
                
                <center><font style="font-family:Verdana; font-size:18px;">
                   Government of India, under the Ministry of Electronics and Information Technology 
                    </font></center>
                
                <br>
                <br>
                <center><font style="font-family:Arial Black; font-size:20px;">
		<?php echo $id;?>
                   </font></center>
                </td>
                    <td colspan="2" width="3%" >
                        <?php
                  
                    $picfile_path ='images/';
                    
                    $result1 = mysqli_query($con,"SELECT * FROM t_userdoc where s_id='".$_SESSION['user']."'");
             
                    while($row1 = mysqli_fetch_array($result1))
                      {                  
                        $picsrc=$picfile_path.$row1['s_pic'];
                        
                        echo "<img src='images/barcode.png' class='img-thumbnail' width='180px' style='height:180px;'>";
                        echo"<div>";
                      }
                   ?>
                        </td>
               
                   </tr>       
                 
                
                
                <tr>
                 <td style="width:4%;"> <font style="font-family: Verdana;">Father's/ Husband Name  </font> </td>
                    <td style="width:8%;" colspan="3"><font style="font-family: Verdana; font-weight: bold">
                     <?php echo $fname;?></font> </td>
                 </tr>

                  <tr>
                 <td style="width:4%;"> <font style="font-family: Verdana;">Address </font> </td>
                    <td style="width:8%;" colspan="3"><font style="font-family: Verdana; font-weight: bold">C/O
                     <?php echo $fname;?></font> </td>
                 </tr>
		<tr>
                 <td style="width:4%;"> <font style="font-family: Verdana;"></font> </td>
                    <td style="width:8%;" colspan="3"><font style="font-family: Verdana; font-weight: bold">
                     <?php echo $ad1;?></font> </td>
                 </tr>
		<tr>
                 <td style="width:4%;"> <font style="font-family: Verdana;"> </font> </td>
                    <td style="width:8%;" colspan="3"><font style="font-family: Verdana; font-weight: bold">
                     <?php echo $ad2;?></font> </td>
                 </tr>
		<tr>
                 <td style="width:4%;"> <font style="font-family: Verdana;"></font> </td>
                    <td style="width:8%;" colspan="3"><font style="font-family: Verdana; font-weight: bold">
                     <?php echo $dis;?></font> </td>
                 </tr>
		<tr>
                 <td style="width:4%;"> <font style="font-family: Verdana;"></font> </td>
                    <td style="width:8%;" colspan="3"><font style="font-family: Verdana; font-weight: bold">
                     <?php echo $state;?></font> </td>
                 </tr>
		<tr>
                 <td style="width:4%;"> <font style="font-family: Verdana;"> </font> </td>
                    <td style="width:8%;" colspan="3"><font style="font-family: Verdana; font-weight: bold">
                     <?php echo $pin;?></font> </td>
                 </tr>
		<tr>
                 <td style="width:4%;"> <font style="font-family: Verdana;"> </font> </td>
                    <td style="width:8%;" colspan="3"><font style="font-family: Verdana; font-weight: bold">
                     <?php echo $smob;?></font> </td>
                 </tr>
		

                 </tr>
                <?php
                }
                ?>
                 
                    </table>
                </div>
             </div>
          </div>
          
         
          </font>
          
          <center><input type="button" id="print" class="toggle btn btn-primary" value="Print" onclick="printpage();"></center>
      </form>
    </body>
</html>







<?php
session_start();
$current = $_SESSION['user'];

$id = $_SESSION['user'];
include 'CERTIFICATE/database_configuration.php';

$sql = "SELECT * FROM t_user_data where s_id = '$id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {

    while($row = $result->fetch_assoc()) {
       $name = $row['s_name'];
$dateofbirth = $row['s_dob'];
$father = $row['fname'];




$state= $row['state'];

$nationality = $_SESSION['user'];

$iid=$_SESSION['user'];



       $date = $row['date'];
$q=mysqli_query($con,"select s_pay from t_user where s_id='".$_SESSION['user']."'");
$n=  mysqli_fetch_assoc($q);
$pay= $n['s_pay'];
    }
} else {
    echo "0 results";
}
$conn->close();
?>

<!DOCTYPE html>
<html><HTML>
<HEAD>
<META NAME="Generator" CONTENT="TextPad 4.4">
<LINK href="general.css" rel="stylesheet" type="text/css">
<script language="JavaScript">
<script language="JavaScript">
<!-- Begin
decodeString();
// End -->
</script>

<script>
function printWindow() {
bV = parseInt(navigator.appVersion);
if (bV >= 1) window.print();
}
//  End -->
</script>

<title> | View data</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style/w3.css">
<link rel="stylesheet" href="style/bootstrap.min.css">
<link rel="icon" href="images/icon.png">
<link rel="stylesheet" href="jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="jquery-1.12.4.js"></script>
  <script src="jquery-ui.js"></script>
  <script>
  $( function() {
    $( "#datepicker" ).datepicker();
  } );
  </script>
 
<style>
input[type=text], input[type=password] , input[type=number]{
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}
table{
background-color:#f1f1c1;
 font-family:palatino;
}
select {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}
#tink{
border-bottom-style: solid;
border-bottom-width: 7px;
border-bottom-color:red}
#yes{
border-bottom-style: solid;
border-bottom-width: 7px;
border-bottom-color:red;

}

</style>
<body>
<div class="w3-container w3-red">

</div>

 

<tr>
                 
                 <td style="width:8%;"><center><font style="font-family:Arial Black; font-size:20px;">
                    Aadhar card </font></center>
     
    
<table valign='top' align="center" style=" color:green; border:1px solid red;border-radius:15px;box-shadow:1px 10px 10px gray">
<tr>
<tr style="color:red"><td>Aadhar No.</td><td><?php echo"$iid"; ?><?php echo""; ?></td></tr>
<tr><td>NAME:</td><td><h3 style="font-family:Courier New;"><?php echo"$name"; ?></h3></td></tr>
<tr><td>Father/Husband Name:</td><td><?php echo"$father"; ?></td></tr>
<tr><td>Date Of Birth:</td><td><?php echo"$dateofbirth"; ?></td></tr>
<tr><td>STATE:</td><td><?php echo"$state"; ?></td></tr>
<tr id="yes" ><td>E-KYC Date:</td><td ><?php echo"$pay"; ?>(YYYY/MM/DD)</td></tr>
<tr id="tink"><td>CODE:</td><td><img src="images/barcode.png" width="150px" height="130px"  ></td></tr>

<tr><td>SIG:</td><td><?php echo"digitally signed verified with Aadhar No."; ?></td></tr>

<tr><td></td><td><h4 style="font-family:Courier New;"><?php echo"$nationality"; ?></td></tr>














<?php
session_start();
$current = $_SESSION['user'];

$id = $_SESSION['user'];
include 'CERTIFICATE/database_configuration.php';

$sql = "SELECT * FROM t_user_data where s_id = '$id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {

    while($row = $result->fetch_assoc()) {
       $father = $row['fname'];
$ad1 = $row['ad1'];
$ad2 = $row['ad2'];


$dis= $row['dis'];
$state= $row['state'];
$pin= $row['pin'];
$sign= $row['s_signupdate'];
$mob= $row['s_mob'];
$nationality = $_SESSION['user'];

$iid=$_SESSION['user'];



       $date = $row['date'];
    }
} else {
    echo "0 results";
}
$conn->close();
?>

<!DOCTYPE html>
<html><HTML>
<HEAD>
<META NAME="Generator" CONTENT="TextPad 4.4">
<LINK href="general.css" rel="stylesheet" type="text/css">
<script language="JavaScript">
<script language="JavaScript">
<!-- Begin
decodeString();
// End -->
</script>

<script>
function printWindow() {
bV = parseInt(navigator.appVersion);
if (bV >= 1) window.print();
}
//  End -->
</script>

<title> | View data</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style/w3.css">
<link rel="stylesheet" href="style/bootstrap.min.css">
<link rel="icon" href="images/icon.png">
<link rel="stylesheet" href="jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="jquery-1.12.4.js"></script>
  <script src="jquery-ui.js"></script>
  <script>
  $( function() {
    $( "#datepicker" ).datepicker();
  } );
  </script>
 
<style>
input[type=text], input[type=password] , input[type=number]{
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}
table{
background-color:#f1f1c1;
 font-family:palatino;
}
select {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}
#tink{
border-bottom-style: solid;
border-bottom-width: 7px;
border-bottom-color:red}
#yes{
border-bottom-style: solid;
border-bottom-width: 7px;
border-bottom-color:red;

}

</style>
<body>
<div class="w3-container w3-red">

</div>

 

  </ul>
     
    
<table valign='top' align="center" style=" color:green; border:1px solid red;border-radius:15px;box-shadow:1px 10px 10px gray">
<tr><br><br>
<tr style="color:red"><td>Aadhar No.</td><td><?php echo"$iid"; ?><?php echo""; ?></td></tr>
<tr><td>Address:</td><td><h3 style="font-family:Courier New;">C/O<?php echo"$fname"; ?></h3></td></tr>
<tr><td></td><td><?php echo"$ad1"; ?></td></tr>
<tr><td></td><td><?php echo"$ad2"; ?></td></tr>
<tr><td></td><td><?php echo"$dis"; ?></td></tr>
<tr id="no" ><td>Pincode</td><td ><?php echo"$pin"; ?></td></tr>
<tr id="yes" ><td>State</td><td ><?php echo"$state"; ?></td></tr>
<tr id="tink"><td></td><td><img src="images/Logo-T.png" width="150px" height="130px"  ></td></tr>

<tr><td>SIG:</td><td><?php echo"digitally signed verified with Aadhar No."; ?></td></tr>

<tr><td>Enrollment ID Num:</td><td><h4 style="font-family:Courier New;"><?php echo"$sign"; ?></td></tr>













		   



                    
                      
                      





                    
                      
                      
               
                      
                      




